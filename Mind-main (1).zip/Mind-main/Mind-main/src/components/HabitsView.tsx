import { ReactNode, useMemo } from "react";
import { Plus, CheckCircle2, Flame, Droplets, Dumbbell, Brain, BookOpen, LayoutGrid, Zap, Moon, Clock } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import type { Habit, Category } from "@/src/types";

const ICON_MAP: Record<string, any> = {
  BookOpen: BookOpen,
  Droplets: Droplets,
  Brain: Brain,
  LayoutGrid: LayoutGrid,
  Dumbbell: Dumbbell,
  Zap: Zap,
  Moon: Moon
};

interface HabitsViewProps {
  habits: Habit[];
  categories: Category[];
  toggleHabit: (id: string) => void;
  onAdd: () => void;
  onSelectHabit: (id: string) => void;
  updateHabitProgress: (id: string, amount: number) => void;
  t: any;
}

export default function HabitsView({ habits, categories, toggleHabit, onAdd, onSelectHabit, updateHabitProgress, t }: HabitsViewProps) {
  const today = new Date().toISOString().split('T')[0];
  const completedToday = habits.filter(h => h.completedDates.includes(today)).length;
  const totalHabits = habits.length;
  const completionRate = totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 0;

  const currentStreak = useMemo(() => {
    if (habits.length === 0) return 0;
    
    let streak = 0;
    let checkDate = new Date();
    checkDate.setHours(0, 0, 0, 0);

    while (true) {
      const dateStr = checkDate.toISOString().split('T')[0];
      const dueHabits = habits.filter(h => {
        const dayOfWeek = checkDate.getDay();
        const dayOfMonth = checkDate.getDate();
        if (h.frequency === "Günlük") return true;
        if (h.frequency === "Haftalık") return h.reminderDays.includes(dayOfWeek);
        if (h.frequency === "Aylık") return h.reminderDays.includes(dayOfMonth);
        if (h.frequency === "Özel") {
          const created = new Date(h.createdAt);
          created.setHours(0, 0, 0, 0);
          const diffTime = Math.abs(checkDate.getTime() - created.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays % h.reminderDays[0] === 0;
        }
        return false;
      });

      if (dueHabits.length === 0) {
        // If no habits were due on this day, we skip it but don't break the streak
        checkDate.setDate(checkDate.getDate() - 1);
        // Safety break to prevent infinite loop if somehow no habits are ever due
        if (streak > 365) break; 
        continue;
      }

      const allCompleted = dueHabits.every(h => h.completedDates.includes(dateStr));
      
      if (allCompleted) {
        streak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        // If it's today and not all are completed yet, we don't break the streak yet
        const isToday = dateStr === new Date().toISOString().split('T')[0];
        if (isToday) {
          checkDate.setDate(checkDate.getDate() - 1);
          continue;
        }
        break;
      }
    }
    return streak;
  }, [habits]);

  return (
    <div className="px-6 pt-8 pb-12">
      <header className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-black text-[#2d2d5f]">{t.habits}</h1>
        <button 
          onClick={onAdd}
          className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-colors"
        >
          <Plus size={28} />
        </button>
      </header>

      <p className="text-gray-400 mb-8 leading-relaxed">
        {t.steps_to_goals}
      </p>

      {/* Stats Summary */}
      <div className="bg-white rounded-[40px] p-8 flex justify-between items-center mb-12 shadow-xl shadow-indigo-100 border border-indigo-50">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{t.daily_streak}</span>
          <span className="text-3xl font-black text-[#2d2d5f]">{currentStreak} {t.days}</span>
        </div>
        <div className="w-px h-12 bg-indigo-100" />
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{t.completion}</span>
          <span className="text-3xl font-black text-[#2d2d5f]">{completionRate}%</span>
        </div>
      </div>

      {/* Category Groups */}
      <div className="space-y-12">
        {categories.map(category => {
          const categoryHabits = habits.filter(h => h.categoryId === category.id);
          if (categoryHabits.length === 0) return null;

          return (
            <div key={category.id}>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-black text-[#2d2d5f]">{category.name}</h3>
                <span className="text-indigo-400 text-sm font-bold">{categoryHabits.length} {t.active}</span>
              </div>
              <div className="space-y-4">
                {categoryHabits.map(habit => (
                  <HabitListItem 
                    key={habit.id} 
                    habit={habit} 
                    category={category}
                    isCompleted={habit.completedDates.includes(today)}
                    onToggle={() => toggleHabit(habit.id)}
                    onUpdateProgress={(amount) => updateHabitProgress(habit.id, amount)}
                    onClick={() => onSelectHabit(habit.id)}
                    t={t}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Add Placeholder */}
      <motion.button 
        whileTap={{ scale: 0.98 }}
        onClick={onAdd}
        className="mt-12 w-full border-2 border-dashed border-indigo-200 rounded-[40px] p-8 flex flex-col items-center gap-4 text-indigo-400 hover:bg-indigo-50 transition-colors"
      >
        <p className="font-bold text-lg">{t.new_goal}</p>
        <div className="flex items-center gap-2 bg-indigo-100 text-indigo-600 px-6 py-2 rounded-full text-sm font-black">
          <Plus size={20} />
          {t.quick_add}
        </div>
      </motion.button>
    </div>
  );
}

function HabitListItem({ habit, category, isCompleted, onToggle, onUpdateProgress, onClick, t }: { habit: Habit, category: Category, isCompleted: boolean, onToggle: () => void, onUpdateProgress: (amount: number) => void, onClick: () => void, t: any, key?: string }) {
  const IconComponent = ICON_MAP[habit.icon] || BookOpen;
  const todayStr = new Date().toISOString().split('T')[0];
  const progress = (habit.dailyProgress || {})[todayStr] || 0;
  const target = habit.targetValue || 1;
  const progressPercent = Math.min(100, (progress / target) * 100);

  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-[40px] p-6 shadow-sm border border-indigo-50 flex flex-col gap-6 cursor-pointer hover:border-indigo-200 transition-colors"
    >
      <div className="flex justify-between items-start">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{category?.name?.toUpperCase() || ""}</span>
            <div className="w-1 h-1 rounded-full bg-indigo-200" />
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest flex items-center gap-1">
              <Clock size={10} /> {habit.reminderTime}
            </span>
          </div>
          <h4 className="text-xl font-black text-[#2d2d5f]">{habit.name}</h4>
          <div className="flex flex-col gap-2 mt-2">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest bg-indigo-50 px-2 py-0.5 rounded-full">
                {habit.frequency === "Günlük" ? t.daily : 
                 habit.frequency === "Haftalık" ? t.weekly : 
                 habit.frequency === "Aylık" ? t.monthly : 
                 t.every_x_days.replace("{x}", habit.reminderDays[0].toString())}
              </span>
            </div>
            {habit.frequency === "Haftalık" && (
              <div className="flex gap-1">
                {t.days_short.map((day: string, i: number) => (
                  <span 
                    key={i} 
                    className={cn(
                      "text-[8px] font-black w-6 h-6 rounded-full flex items-center justify-center",
                      habit.reminderDays.includes(i) ? "bg-indigo-100 text-indigo-600" : "text-gray-300"
                    )}
                  >
                    {day[0]}
                  </span>
                ))}
              </div>
            )}
            {habit.frequency === "Aylık" && (
              <div className="flex flex-wrap gap-1 max-w-[200px]">
                {habit.reminderDays.map(day => (
                  <span key={day} className="text-[8px] font-black w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center">
                    {day}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
        <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600">
          <IconComponent size={24} />
        </div>
      </div>

      {habit.goalType === "numeric" && (
        <div className="space-y-2">
          <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
            <span className="text-gray-400">{t.progress}: {progress} / {target} {habit.unit}</span>
            <span className={cn(isCompleted ? "text-emerald-500" : "text-indigo-400")}>{progressPercent}%</span>
          </div>
          <div className="w-full h-2 bg-indigo-50 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              className={cn("h-full", isCompleted ? "bg-emerald-500" : "bg-indigo-500")}
            />
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2 text-emerald-600 font-bold">
          <Flame size={20} fill="currentColor" />
          <span>{habit.streak} {t.streak}</span>
        </div>
        
        {habit.goalType === "boolean" ? (
          isCompleted ? (
            <div className="flex items-center gap-2 text-emerald-600 font-black text-sm">
              <CheckCircle2 size={20} />
              {t.completed_today}
            </div>
          ) : (
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onToggle();
              }}
              className="bg-indigo-600 text-white px-6 py-2 rounded-full text-sm font-black hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
            >
              {t.mark_done}
            </button>
          )
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onUpdateProgress(-1);
              }}
              className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-black"
            >
              -
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onUpdateProgress(1);
              }}
              className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center font-black",
                isCompleted ? "bg-emerald-600 text-white" : "bg-indigo-600 text-white"
              )}
            >
              +
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
