import { useState, FormEvent } from "react";
import { ChevronLeft, Plus, Trash2, Edit2, BookOpen, Droplets, Brain, LayoutGrid, Dumbbell, Zap, Moon } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "@/src/lib/utils";
import type { Category } from "@/src/types";

interface CategoriesViewProps {
  categories: Category[];
  onAdd: (category: Omit<Category, "id">) => void;
  onUpdate: (category: Category) => void;
  onDelete: (id: string) => void;
  onBack: () => void;
  t: any;
}

const COLORS = ["#6366f1", "#10b981", "#ef4444", "#8b5cf6", "#f59e0b", "#3b82f6"];
const ICONS = [
  { name: "Droplets", icon: <Droplets size={24} /> },
  { name: "Brain", icon: <Brain size={24} /> },
  { name: "LayoutGrid", icon: <LayoutGrid size={24} /> },
  { name: "BookOpen", icon: <BookOpen size={24} /> },
  { name: "Dumbbell", icon: <Dumbbell size={24} /> },
  { name: "Zap", icon: <Zap size={24} /> },
  { name: "Moon", icon: <Moon size={24} /> },
];

const ICON_MAP: Record<string, any> = {
  BookOpen: BookOpen,
  Droplets: Droplets,
  Brain: Brain,
  LayoutGrid: LayoutGrid,
  Dumbbell: Dumbbell,
  Zap: Zap,
  Moon: Moon
};

export default function CategoriesView({ categories, onAdd, onUpdate, onDelete, onBack, t }: CategoriesViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("LayoutGrid");
  const [color, setColor] = useState(COLORS[0]);

  const resetForm = () => {
    setName("");
    setIcon("LayoutGrid");
    setColor(COLORS[0]);
    setIsAdding(false);
    setEditingCategory(null);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingCategory) {
      onUpdate({ ...editingCategory, name, icon, color });
    } else {
      onAdd({ name, icon, color });
    }
    resetForm();
  };

  const startEdit = (category: Category) => {
    setEditingCategory(category);
    setName(category.name);
    setIcon(category.icon);
    setColor(category.color);
    setIsAdding(true);
  };

  return (
    <div className="px-6 pt-8 pb-32">
      <header className="flex justify-between items-center mb-12">
        <button 
          onClick={onBack}
          className="p-3 text-[#2d2d5f] hover:bg-indigo-50 rounded-2xl transition-colors"
        >
          <ChevronLeft size={28} />
        </button>
        <h1 className="text-2xl font-black text-[#2d2d5f]">{t.categories}</h1>
        <button 
          onClick={() => setIsAdding(true)}
          className="p-3 text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-colors"
        >
          <Plus size={28} />
        </button>
      </header>

      <AnimatePresence>
        {isAdding && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-white rounded-[40px] p-8 shadow-xl border border-indigo-50 mb-12"
          >
            <h2 className="text-xl font-black text-[#2d2d5f] mb-8">
              {editingCategory ? t.edit_category : t.add_category}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-8">
              <div>
                <label className="text-sm font-black text-[#2d2d5f] mb-4 block">{t.category_name}</label>
                <input 
                  type="text" 
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t.category_placeholder}
                  className="w-full bg-indigo-50/50 border-none rounded-[30px] p-6 text-lg font-bold placeholder:text-gray-300 focus:ring-2 focus:ring-indigo-200 transition-all"
                />
              </div>

              <div>
                <label className="text-sm font-black text-[#2d2d5f] mb-6 block">{t.symbol}</label>
                <div className="grid grid-cols-4 gap-4">
                  {ICONS.map(item => (
                    <button
                      key={item.name}
                      type="button"
                      onClick={() => setIcon(item.name)}
                      className={cn(
                        "w-14 h-14 rounded-2xl flex items-center justify-center transition-all",
                        icon === item.name ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "bg-indigo-100 text-indigo-600"
                      )}
                    >
                      {item.icon}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm font-black text-[#2d2d5f] mb-6 block">{t.color_palette}</label>
                <div className="flex gap-4">
                  {COLORS.map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={cn(
                        "w-10 h-10 rounded-full transition-all flex items-center justify-center",
                        color === c ? "ring-4 ring-indigo-100" : ""
                      )}
                      style={{ backgroundColor: c }}
                    >
                      {color === c && <div className="w-2 h-2 bg-white rounded-full" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={resetForm}
                  className="flex-1 bg-gray-100 text-gray-600 rounded-[30px] p-6 text-lg font-black hover:bg-gray-200 transition-all"
                >
                  {t.cancel}
                </button>
                <button 
                  type="submit"
                  className="flex-1 bg-indigo-500 text-white rounded-[30px] p-6 text-lg font-black shadow-xl shadow-indigo-100 hover:bg-indigo-600 transition-all"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {categories.map(category => {
          const IconComponent = ICON_MAP[category.icon] || LayoutGrid;
          return (
            <motion.div 
              layout
              key={category.id}
              className="bg-white rounded-[40px] p-6 shadow-sm border border-indigo-50 flex items-center gap-4"
            >
              <div 
                className="w-12 h-12 rounded-2xl flex items-center justify-center text-white"
                style={{ backgroundColor: category.color }}
              >
                <IconComponent size={24} />
              </div>
              <div className="flex-1">
                <h4 className="text-xl font-black text-[#2d2d5f]">{category.name}</h4>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => startEdit(category)}
                  className="p-2 text-indigo-400 hover:text-indigo-600 transition-colors"
                >
                  <Edit2 size={20} />
                </button>
                <button 
                  onClick={() => onDelete(category.id)}
                  className="p-2 text-red-300 hover:text-red-500 transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
