import { ReactNode, useMemo } from "react";
import { BarChart, Bar, XAxis, ResponsiveContainer, Cell, Tooltip, CartesianGrid, AreaChart, Area, YAxis } from 'recharts';
import { Trophy, Droplets, Brain, Dumbbell, LayoutGrid, BookOpen, ArrowUpRight, Zap, Moon, Flame, Target, TrendingUp } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import type { Habit, Achievement, Category } from "@/src/types";

const ICON_MAP: Record<string, any> = {
  BookOpen: BookOpen,
  Droplets: Droplets,
  Brain: Brain,
  LayoutGrid: LayoutGrid,
  Dumbbell: Dumbbell,
  Zap: Zap,
  Moon: Moon,
  Flame: Flame,
  Target: Target,
  TrendingUp: TrendingUp
};

interface StatsViewProps {
  habits: Habit[];
  categories: Category[];
  achievements: Achievement[];
  points: number;
  level: number;
  levelProgress: number;
  pointsToNextLevel: number;
  t: any;
  onSeeAllAchievements: () => void;
}

export default function StatsView({ habits, categories, achievements, points, level, levelProgress, pointsToNextLevel, t, onSeeAllAchievements }: StatsViewProps) {
  const weeklyData = useMemo(() => {
    const days = [];
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      
      const dueHabits = habits.filter(h => {
        const dayOfWeek = date.getDay();
        const dayOfMonth = date.getDate();
        if (h.frequency === "Günlük") return true;
        if (h.frequency === "Haftalık") return h.reminderDays.includes(dayOfWeek);
        if (h.frequency === "Aylık") return h.reminderDays.includes(dayOfMonth);
        if (h.frequency === "Özel") {
          const created = new Date(h.createdAt);
          created.setHours(0, 0, 0, 0);
          const current = new Date(date);
          current.setHours(0, 0, 0, 0);
          const diffTime = Math.abs(current.getTime() - created.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          return diffDays % h.reminderDays[0] === 0;
        }
        return false;
      });

      const completedCount = dueHabits.filter(h => h.completedDates.includes(dateStr)).length;
      const completionRate = dueHabits.length > 0 ? Math.round((completedCount / dueHabits.length) * 100) : 0;
      
      days.push({
        name: t.days_short[date.getDay()],
        value: completionRate
      });
    }
    return days;
  }, [habits, t.days_short]);

  const weeklyIncrease = useMemo(() => {
    if (habits.length === 0) return 0;
    
    const getWeekRate = (offset: number) => {
      let totalDue = 0;
      let totalCompleted = 0;
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      for (let i = 0; i < 7; i++) {
        const date = new Date(today);
        date.setDate(today.getDate() - (offset * 7) - i);
        const dateStr = date.toISOString().split('T')[0];
        
        const dueHabits = habits.filter(h => {
          const dayOfWeek = date.getDay();
          const dayOfMonth = date.getDate();
          if (h.frequency === "Günlük") return true;
          if (h.frequency === "Haftalık") return h.reminderDays.includes(dayOfWeek);
          if (h.frequency === "Aylık") return h.reminderDays.includes(dayOfMonth);
          if (h.frequency === "Özel") {
            const created = new Date(h.createdAt);
            created.setHours(0, 0, 0, 0);
            const current = new Date(date);
            current.setHours(0, 0, 0, 0);
            const diffTime = Math.abs(current.getTime() - created.getTime());
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            return diffDays % h.reminderDays[0] === 0;
          }
          return false;
        });

        totalDue += dueHabits.length;
        totalCompleted += dueHabits.filter(h => h.completedDates.includes(dateStr)).length;
      }
      return totalDue > 0 ? (totalCompleted / totalDue) * 100 : 0;
    };

    const currentWeekRate = getWeekRate(0);
    const lastWeekRate = getWeekRate(1);
    
    if (lastWeekRate === 0) return currentWeekRate > 0 ? Math.round(currentWeekRate) : 0;
    return Math.round(currentWeekRate - lastWeekRate);
  }, [habits]);

  const monthlyStats = useMemo(() => {
    const today = new Date();
    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();
    
    let totalCompletions = 0;
    habits.forEach(h => {
      h.completedDates.forEach(dateStr => {
        const date = new Date(dateStr);
        if (date.getMonth() === currentMonth && date.getFullYear() === currentYear) {
          totalCompletions++;
        }
      });
    });

    // Estimate goal: 20 completions per habit per month
    const monthlyGoal = habits.length * 20;
    const progress = monthlyGoal > 0 ? Math.min(100, Math.round((totalCompletions / monthlyGoal) * 100)) : 0;
    
    return {
      total: totalCompletions,
      goal: monthlyGoal,
      progress
    };
  }, [habits]);

  return (
    <div className="px-6 pt-8 pb-12">
      <header className="mb-8">
        <h1 className="text-3xl font-black mb-2 leading-tight">{t.stats_title}</h1>
        <p className="text-gray-400 text-sm">{t.stats_subtitle}</p>
      </header>

      {/* Level & Points Card */}
      <div className="bg-white rounded-[40px] p-8 mb-8 shadow-sm border border-indigo-50 relative overflow-hidden">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-100">
              <Zap size={24} fill="currentColor" />
            </div>
            <div>
              <h3 className="text-xl font-black text-[#2d2d5f]">{t.level} {level}</h3>
              <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{t.total_points}: {points}</p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{t.next_level}</span>
            <p className="text-sm font-black text-[#2d2d5f]">{t.points_to_next.replace("{points}", pointsToNextLevel.toString())}</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-[10px] font-black text-gray-400 uppercase tracking-widest">
            <span>{t.level} {level}</span>
            <span>{t.level} {level + 1}</span>
          </div>
          <div className="h-3 w-full bg-indigo-50 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${levelProgress}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="h-full bg-indigo-500 rounded-full shadow-[0_0_10px_rgba(99,102,241,0.5)]"
            />
          </div>
        </div>
      </div>

      {/* Weekly Completion Chart */}
      <div className="bg-white rounded-[40px] p-8 mb-8 shadow-sm border border-gray-50">
        <div className="flex justify-between items-start mb-8">
          <div>
            <h3 className="text-xl font-black text-[#2d2d5f]">{t.weekly_completion}</h3>
            <p className="text-sm text-gray-400">{t.weekly_perf}</p>
          </div>
          {habits.length > 0 && weeklyIncrease !== 0 && (
            <div className={cn(
              "px-3 py-1 rounded-full text-xs font-black flex items-center gap-1",
              weeklyIncrease > 0 ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600"
            )}>
              <ArrowUpRight size={14} className={cn(weeklyIncrease < 0 && "rotate-90")} />
              <span>%{Math.abs(weeklyIncrease)} {weeklyIncrease > 0 ? t.increase : t.decrease}</span>
            </div>
          )}
        </div>

        <div className="h-48 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fontSize: 10, fontWeight: 'bold', fill: '#94a3b8' }} 
              />
              <Tooltip 
                cursor={{ fill: "#f8fafc" }}
                contentStyle={{ borderRadius: "16px", border: "none", boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)" }}
              />
              <Bar dataKey="value" radius={[10, 10, 10, 10]} barSize={12}>
                {weeklyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={index === weeklyData.length - 1 ? '#6366f1' : '#e2e8f0'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Monthly Progress Card */}
      <div className="bg-indigo-600 rounded-[40px] p-8 text-white mb-12 shadow-xl shadow-indigo-100">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold text-lg">{t.monthly_progress}</h3>
          <span className="text-indigo-400 text-xs font-bold uppercase tracking-widest">{new Intl.DateTimeFormat('tr-TR', { month: 'long' }).format(new Date())}</span>
        </div>
        <div className="flex items-end gap-4 mb-4">
          <span className="text-5xl font-black">{monthlyStats.total}</span>
          <span className="text-indigo-400 font-bold mb-2">/ {monthlyStats.goal} {t.total_goal}</span>
        </div>
        <div className="w-full h-3 bg-white/10 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${monthlyStats.progress}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="h-full bg-white rounded-full shadow-[0_0_15px_rgba(255,255,255,0.5)]"
          />
        </div>
      </div>

      {/* Achievement Badges */}
      <div className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-2xl font-black text-[#2d2d5f]">{t.achievements}</h3>
          <button 
            onClick={onSeeAllAchievements}
            className="text-indigo-500 text-sm font-bold"
          >
            {t.see_all}
          </button>
        </div>
        <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
          {achievements.map((achievement, i) => (
            <div 
              key={i} 
              className={cn(
                "flex-shrink-0 w-32 h-40 rounded-[40px] flex flex-col items-center justify-center gap-4 shadow-sm border border-gray-50",
                achievement.unlocked ? "bg-indigo-50" : "bg-gray-50 opacity-50"
              )}
            >
              <div className="w-14 h-14 rounded-full bg-white flex items-center justify-center text-indigo-600 shadow-sm">
                {achievement.icon === "Trophy" ? <Trophy size={24} /> : 
                 achievement.icon === "Droplets" ? <Droplets size={24} /> : 
                 achievement.icon === "Brain" ? <Brain size={24} /> : 
                 <Zap size={24} />}
              </div>
              <span className="text-[10px] font-black text-center px-4 leading-tight uppercase tracking-wider">
                {t.achievements_list?.[achievement.title] || achievement.title}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Category Details */}
      <div className="mb-12">
        <h3 className="text-2xl font-black text-[#2d2d5f] mb-6">{t.category_details}</h3>
        <div className="space-y-4">
          {categories.map(category => {
            const categoryHabits = habits.filter(h => h.categoryId === category.id);
            const avgStreak = categoryHabits.length > 0 ? categoryHabits.reduce((acc, h) => acc + h.streak, 0) / categoryHabits.length : 0;
            const progress = Math.min(100, Math.round(avgStreak * 5)); 

            return (
              <CategoryProgress 
                key={category.id}
                label={category.name} 
                progress={progress} 
                color={category.color} 
                iconName={category.icon} 
              />
            );
          })}
        </div>
      </div>

      {/* Habit Detailed Stats */}
      <div>
        <h3 className="text-2xl font-black text-[#2d2d5f] mb-6">{t.habit_stats}</h3>
        <div className="space-y-6">
          {habits.map(habit => (
            <HabitDetailedCard key={habit.id} habit={habit} t={t} />
          ))}
        </div>
      </div>
    </div>
  );
}

function HabitDetailedCard({ habit, t }: { habit: Habit, t: any, key?: string }) {
  const stats = useMemo(() => {
    const totalCompletions = habit.completedDates.length;
    const createdAtDate = new Date(habit.createdAt);
    const daysSinceCreation = Math.max(1, Math.ceil((new Date().getTime() - createdAtDate.getTime()) / (1000 * 60 * 60 * 24)));
    const completionRate = Math.round((totalCompletions / daysSinceCreation) * 100);

    // Trend data for the last 4 weeks
    const trendData = [];
    const today = new Date();
    for (let i = 3; i >= 0; i--) {
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - (i * 7) - today.getDay());
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);

      const completionsInWeek = habit.completedDates.filter(dateStr => {
        const date = new Date(dateStr);
        return date >= startOfWeek && date <= endOfWeek;
      }).length;

      trendData.push({
        week: `${4-i}. Hafta`,
        value: completionsInWeek
      });
    }

    return { totalCompletions, completionRate, trendData };
  }, [habit]);

  return (
    <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-50">
      <div className="flex items-center gap-4 mb-6">
        <div 
          className="w-12 h-12 rounded-2xl flex items-center justify-center text-white shadow-lg"
          style={{ backgroundColor: habit.color }}
        >
          <Target size={24} />
        </div>
        <div>
          <h4 className="text-lg font-black text-[#2d2d5f]">{habit.name}</h4>
          <div className="flex gap-4 mt-1">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1">
              <Flame size={12} className="text-orange-500" fill="currentColor" />
              {habit.streak} {t.streak}
            </span>
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-1">
              <TrendingUp size={12} className="text-emerald-500" />
              {stats.completionRate}% {t.completion}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 rounded-3xl p-4">
          <div className="text-2xl font-black text-[#2d2d5f]">{stats.totalCompletions}</div>
          <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.total_completions}</div>
        </div>
        <div className="bg-gray-50 rounded-3xl p-4">
          <div className="text-2xl font-black text-[#2d2d5f]">{habit.streak}</div>
          <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.daily_streak}</div>
        </div>
      </div>

      <div className="h-24 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={stats.trendData}>
            <defs>
              <linearGradient id={`gradient-${habit.id}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={habit.color} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={habit.color} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <Tooltip 
              contentStyle={{ borderRadius: "16px", border: "none", boxShadow: "0 10px 15px -3px rgb(0 0 0 / 0.1)" }}
            />
            <Area 
              type="monotone" 
              dataKey="value" 
              stroke={habit.color} 
              strokeWidth={3}
              fillOpacity={1} 
              fill={`url(#gradient-${habit.id})`} 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="text-center mt-2">
        <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">{t.weekly_trend}</span>
      </div>
    </div>
  );
}

function CategoryProgress({ label, progress, color, iconName }: { label: string, progress: number, color: string, iconName: string, key?: string }) {
  const IconComponent = ICON_MAP[iconName] || BookOpen;
  return (
    <div className="bg-white rounded-[40px] p-6 shadow-sm border border-gray-50 flex items-center gap-4">
      <div className="w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600">
        <IconComponent size={20} />
      </div>
      <div className="flex-1">
        <div className="flex justify-between items-center mb-2">
          <span className="font-bold text-[#2d2d5f]">{label}</span>
          <span className="text-sm font-black" style={{ color }}>%{progress}</span>
        </div>
        <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="h-full rounded-full"
            style={{ backgroundColor: color }}
          />
        </div>
      </div>
    </div>
  );
}
