import { useState, ReactNode, FormEvent } from "react";
import { ChevronLeft, Plus, Clock, Droplets, Brain, LayoutGrid, BookOpen, Dumbbell, Zap, Moon, Volume2, Play, CheckCircle2, Target } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import type { Habit, Category } from "@/src/types";
import { REMINDER_SOUNDS } from "@/src/constants";

interface AddHabitViewProps {
  categories: Category[];
  onAdd: (habit: Omit<Habit, "id" | "streak" | "completedDates" | "createdAt">) => void;
  onUpdate?: (id: string, habit: Partial<Habit>) => void;
  onBack: () => void;
  initialHabit?: Habit;
  t: any;
}

const COLORS = ["#6366f1", "#10b981", "#ef4444", "#8b5cf6", "#f59e0b", "#3b82f6"];
const ICONS = [
  { name: "Droplets", icon: <Droplets size={24} /> },
  { name: "Brain", icon: <Brain size={24} /> },
  { name: "LayoutGrid", icon: <LayoutGrid size={24} /> },
  { name: "BookOpen", icon: <BookOpen size={24} /> },
  { name: "Dumbbell", icon: <Dumbbell size={24} /> },
  { name: "Zap", icon: <Zap size={24} /> },
  { name: "Moon", icon: <Moon size={24} /> },
];

export default function AddHabitView({ categories, onAdd, onUpdate, onBack, initialHabit, t }: AddHabitViewProps) {
  const [name, setName] = useState(initialHabit?.name || "");
  const [categoryId, setCategoryId] = useState<string>(initialHabit?.categoryId || categories[0]?.id || "");
  const [icon, setIcon] = useState(initialHabit?.icon || "Droplets");
  const [color, setColor] = useState(initialHabit?.color || COLORS[0]);
  const [frequency, setFrequency] = useState<"Günlük" | "Haftalık" | "Aylık" | "Özel">(initialHabit?.frequency || "Günlük");
  const [reminderTime, setReminderTime] = useState(initialHabit?.reminderTime || "08:30");
  const [reminderDays, setReminderDays] = useState<number[]>(initialHabit?.reminderDays || [1, 2, 3, 4, 5]);
  const [remindersEnabled, setRemindersEnabled] = useState(initialHabit?.remindersEnabled ?? true);
  const [reminderSound, setReminderSound] = useState(initialHabit?.reminderSound || "default");
  const [goalType, setGoalType] = useState<"boolean" | "numeric">(initialHabit?.goalType || "boolean");
  const [targetValue, setTargetValue] = useState(initialHabit?.targetValue || 8);
  const [unit, setUnit] = useState(initialHabit?.unit || "");
  const [customInterval, setCustomInterval] = useState(initialHabit?.frequency === "Özel" ? initialHabit.reminderDays[0] : 2);

  const playSound = (soundId: string) => {
    const sound = REMINDER_SOUNDS.find(s => s.id === soundId);
    if (sound) {
      const audio = new Audio(sound.url);
      audio.play().catch(err => console.error("Error playing sound:", err));
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const habitData = {
      name,
      categoryId,
      icon,
      color,
      frequency,
      reminderTime,
      reminderDays: frequency === "Özel" ? [customInterval] : reminderDays,
      remindersEnabled,
      reminderSound,
      goalType,
      targetValue: goalType === "numeric" ? targetValue : undefined,
      unit: goalType === "numeric" ? unit : undefined,
      dailyProgress: initialHabit?.dailyProgress || {},
    };

    if (initialHabit && onUpdate) {
      onUpdate(initialHabit.id, habitData);
    } else {
      onAdd(habitData);
    }
  };

  return (
    <div className="px-6 pt-8 pb-32">
      <header className="flex justify-between items-center mb-12">
        <button 
          onClick={onBack}
          className="p-3 text-[#2d2d5f] hover:bg-indigo-50 rounded-2xl transition-colors"
        >
          <ChevronLeft size={28} />
        </button>
        <h1 className="text-2xl font-black text-[#2d2d5f]">{initialHabit ? t.edit_habit : t.new_habit}</h1>
        <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center overflow-hidden border-2 border-white shadow-sm">
          <img 
            src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" 
            alt="Profile" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
      </header>

      <div className="mb-12">
        <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-2 block">{t.change_starts}</span>
        <h2 className="text-4xl font-black text-[#2d2d5f] leading-tight">{t.steps_to_goals}</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-12">
        {/* Habit Name */}
        <div>
          <label className="text-sm font-black text-[#2d2d5f] mb-4 block">{t.habit_name}</label>
          <input 
            type="text" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t.habit_placeholder}
            className="w-full bg-indigo-50/50 border-none rounded-[30px] p-6 text-lg font-bold placeholder:text-gray-300 focus:ring-2 focus:ring-indigo-200 transition-all"
          />
        </div>

        {/* Category Selection */}
        <div>
          <label className="text-sm font-black text-[#2d2d5f] mb-4 block">{t.category}</label>
          <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
            {categories.map(cat => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setCategoryId(cat.id)}
                className={cn(
                  "px-6 py-3 rounded-full text-sm font-black transition-all whitespace-nowrap",
                  categoryId === cat.id ? "bg-emerald-400 text-white shadow-lg shadow-emerald-100" : "bg-indigo-50 text-indigo-900"
                )}
              >
                {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Icon Selection */}
        <div className="bg-indigo-50/30 rounded-[40px] p-8">
          <label className="text-sm font-black text-[#2d2d5f] mb-6 block">{t.symbol}</label>
          <div className="grid grid-cols-4 gap-4">
            {ICONS.map(item => (
              <button
                key={item.name}
                type="button"
                onClick={() => setIcon(item.name)}
                className={cn(
                  "w-14 h-14 rounded-2xl flex items-center justify-center transition-all",
                  icon === item.name ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "bg-indigo-100 text-indigo-600"
                )}
              >
                {item.icon}
              </button>
            ))}
          </div>
        </div>

        {/* Goal Type Selection */}
        <div className="bg-indigo-50/30 rounded-[40px] p-8 space-y-6">
          <label className="text-sm font-black text-[#2d2d5f] mb-2 block">{t.goal_type}</label>
          
          <div className="bg-indigo-100 p-1.5 rounded-[24px] flex gap-1.5">
            {(["boolean", "numeric"] as const).map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => setGoalType(g)}
                className={cn(
                  "flex-1 py-3 rounded-[18px] text-xs font-black transition-all flex items-center justify-center gap-2",
                  goalType === g 
                    ? "bg-white text-indigo-600 shadow-md shadow-indigo-100/50" 
                    : "text-indigo-400 hover:text-indigo-500"
                )}
              >
                {g === "boolean" ? <CheckCircle2 size={16} /> : <Target size={16} />}
                {g === "boolean" ? t.boolean_goal : t.numeric_goal}
              </button>
            ))}
          </div>

          {goalType === "numeric" && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="grid grid-cols-2 gap-4 pt-2"
            >
              <div className="space-y-2">
                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-2">{t.target_value}</label>
                <input 
                  type="number" 
                  value={targetValue}
                  onChange={(e) => setTargetValue(parseInt(e.target.value) || 1)}
                  className="w-full bg-indigo-100 border-2 border-transparent focus:border-indigo-200 focus:bg-white outline-none rounded-2xl p-4 font-black text-indigo-600 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-indigo-400 uppercase tracking-widest ml-2">{t.unit}</label>
                <input 
                  type="text" 
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder={t.unit_placeholder}
                  className="w-full bg-indigo-100 border-2 border-transparent focus:border-indigo-200 focus:bg-white outline-none rounded-2xl p-4 font-black text-indigo-600 placeholder:text-indigo-300 transition-all"
                />
              </div>
            </motion.div>
          )}
        </div>

        {/* Color Palette */}
        <div className="bg-indigo-50/30 rounded-[40px] p-8">
          <label className="text-sm font-black text-[#2d2d5f] mb-6 block">{t.color_palette}</label>
          <div className="flex gap-4">
            {COLORS.map(c => (
              <button
                key={c}
                type="button"
                onClick={() => setColor(c)}
                className={cn(
                  "w-10 h-10 rounded-full transition-all flex items-center justify-center",
                  color === c ? "ring-4 ring-indigo-100" : ""
                )}
                style={{ backgroundColor: c }}
              >
                {color === c && <div className="w-2 h-2 bg-white rounded-full" />}
              </button>
            ))}
          </div>
        </div>

        {/* Frequency & Reminder */}
        <div className="bg-indigo-50/30 rounded-[40px] p-8 space-y-8">
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-center">
              <div>
                <label className="text-sm font-black text-[#2d2d5f] mb-1 block">{t.frequency}</label>
                <p className="text-xs text-gray-400">{t.daily} / {t.weekly} / {t.monthly}?</p>
              </div>
              <div className="bg-indigo-100 p-1 rounded-2xl flex flex-wrap gap-1">
                {(["Günlük", "Haftalık", "Aylık", "Özel"] as const).map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => {
                      setFrequency(f);
                      if (f === "Günlük") setReminderDays([0, 1, 2, 3, 4, 5, 6]);
                      else if (f === "Haftalık") setReminderDays([1, 2, 3, 4, 5]);
                      else if (f === "Aylık") setReminderDays([1]);
                      else setReminderDays([customInterval]);
                    }}
                    className={cn(
                      "px-3 py-2 rounded-xl text-xs font-black transition-all",
                      frequency === f ? "bg-white text-indigo-600 shadow-sm" : "text-indigo-400"
                    )}
                  >
                    {f === "Günlük" ? t.daily : f === "Haftalık" ? t.weekly : f === "Aylık" ? t.monthly : t.custom}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="w-full h-px bg-indigo-100" />

          <div className="flex justify-between items-center">
            <div>
              <label className="text-sm font-black text-[#2d2d5f] mb-1 block">{t.reminders}</label>
              <p className="text-xs text-gray-400">{remindersEnabled ? t.reminders_on : t.reminders_off}</p>
            </div>
            <button
              type="button"
              onClick={() => setRemindersEnabled(!remindersEnabled)}
              className={cn(
                "w-14 h-8 rounded-full transition-all relative p-1",
                remindersEnabled ? "bg-indigo-500" : "bg-gray-200"
              )}
            >
              <div className={cn(
                "w-6 h-6 bg-white rounded-full shadow-sm transition-all absolute top-1",
                remindersEnabled ? "left-7" : "left-1"
              )} />
            </button>
          </div>

          {remindersEnabled && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-6 pt-4"
            >
              <div className="flex justify-between items-center">
                <div>
                  <label className="text-sm font-black text-[#2d2d5f] mb-1 block">{t.reminder_time}</label>
                  <p className="text-xs text-gray-400">{t.reminder}...</p>
                </div>
                <div className="bg-indigo-100 px-4 py-2 rounded-2xl flex items-center gap-2 text-indigo-600 font-black text-xs">
                  <Clock size={16} />
                  <input 
                    type="time" 
                    value={reminderTime}
                    onChange={(e) => setReminderTime(e.target.value)}
                    className="bg-transparent w-20 focus:outline-none font-black"
                  />
                </div>
              </div>

              {frequency === "Haftalık" && (
                <div>
                  <label className="text-sm font-black text-[#2d2d5f] mb-4 block">{t.reminder_days}</label>
                  <div className="flex justify-between">
                    {t.days_short.map((day: string, index: number) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => {
                          setReminderDays(prev => 
                            prev.includes(index) 
                              ? prev.filter(d => d !== index) 
                              : [...prev, index].sort()
                          );
                        }}
                        className={cn(
                          "w-10 h-10 rounded-full text-[10px] font-black transition-all",
                          reminderDays.includes(index) ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "bg-indigo-100 text-indigo-400"
                        )}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {frequency === "Aylık" && (
                <div>
                  <label className="text-sm font-black text-[#2d2d5f] mb-4 block">{t.monthly_days}</label>
                  <div className="grid grid-cols-7 gap-2">
                    {Array.from({ length: 31 }, (_, i) => i + 1).map(day => (
                      <button
                        key={day}
                        type="button"
                        onClick={() => {
                          setReminderDays(prev => 
                            prev.includes(day) 
                              ? prev.filter(d => d !== day) 
                              : [...prev, day].sort((a, b) => a - b)
                          );
                        }}
                        className={cn(
                          "w-8 h-8 rounded-lg text-[10px] font-black transition-all",
                          reminderDays.includes(day) ? "bg-indigo-600 text-white" : "bg-indigo-100 text-indigo-400"
                        )}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="w-full h-px bg-indigo-100" />

              <div>
                <label className="text-sm font-black text-[#2d2d5f] mb-4 block">{t.reminder_sound}</label>
                <div className="space-y-3">
                  {REMINDER_SOUNDS.map(sound => (
                    <div
                      key={sound.id}
                      onClick={() => setReminderSound(sound.id)}
                      className={cn(
                        "w-full p-4 rounded-2xl flex items-center justify-between transition-all cursor-pointer",
                        reminderSound === sound.id ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "bg-indigo-100 text-indigo-600"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <Volume2 size={18} />
                        <span className="font-bold text-sm">{sound.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          playSound(sound.id);
                        }}
                        className={cn(
                          "p-2 rounded-xl transition-colors",
                          reminderSound === sound.id ? "bg-white/20 hover:bg-white/30" : "bg-indigo-200 hover:bg-indigo-300"
                        )}
                      >
                        <Play size={14} fill="currentColor" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Custom Interval */}
        {frequency === "Özel" && (
          <div className="bg-indigo-50/30 rounded-[40px] p-8">
            <label className="text-sm font-black text-[#2d2d5f] mb-6 block">{t.custom}</label>
            <div className="flex items-center gap-4">
              <input 
                type="number" 
                min="1" 
                max="365"
                value={customInterval}
                onChange={(e) => setCustomInterval(parseInt(e.target.value) || 1)}
                className="w-20 bg-indigo-100 border-none rounded-2xl p-4 text-center font-black text-indigo-600"
              />
              <span className="text-sm font-bold text-gray-400">{t.every_x_days.replace("{x}", customInterval.toString())}</span>
            </div>
          </div>
        )}

        {/* Growth Tips */}
        <div>
          <h3 className="text-xl font-black text-[#2d2d5f] mb-6">{t.growth_tips}</h3>
          <div className="space-y-4">
            <TipCard 
              icon={<Zap size={20} />} 
              title={t.tip1_title} 
              description={t.tip1_desc} 
            />
            <TipCard 
              icon={<LayoutGrid size={20} />} 
              title={t.tip2_title} 
              description={t.tip2_desc} 
            />
          </div>
        </div>

        <button 
          type="submit"
          className="w-full bg-indigo-500 text-white rounded-[30px] p-6 text-lg font-black shadow-xl shadow-indigo-100 hover:bg-indigo-600 transition-all"
        >
          {initialHabit ? t.save : t.start_habit}
        </button>
      </form>
    </div>
  );
}

function TipCard({ icon, title, description }: { icon: ReactNode, title: string, description: string }) {
  return (
    <div className="bg-white rounded-[40px] p-6 shadow-sm border border-gray-50 flex items-start gap-4">
      <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center flex-shrink-0">
        {icon}
      </div>
      <div>
        <h4 className="font-bold text-[#2d2d5f] mb-1">{title}</h4>
        <p className="text-xs text-gray-400 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
