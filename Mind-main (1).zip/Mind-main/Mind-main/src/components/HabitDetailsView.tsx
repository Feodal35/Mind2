import { ChevronLeft, Edit2, Trash2, Flame, Calendar, Clock, Target, Volume2 } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import type { Habit, Category } from "@/src/types";
import CalendarHeatmap from "./CalendarHeatmap";
import { REMINDER_SOUNDS } from "@/src/constants";

interface HabitDetailsViewProps {
  habit: Habit;
  category?: Category;
  onBack: () => void;
  onEdit: () => void;
  onDelete: () => void;
  onViewHistory: () => void;
  t: any;
}

export default function HabitDetailsView({ habit, category, onBack, onEdit, onDelete, onViewHistory, t }: HabitDetailsViewProps) {
  const totalCompletions = habit.completedDates.length;
  const createdAtDate = new Date(habit.createdAt);
  const daysSinceCreation = Math.max(1, Math.ceil((new Date().getTime() - createdAtDate.getTime()) / (1000 * 60 * 60 * 24)));
  const completionRate = Math.round((totalCompletions / daysSinceCreation) * 100);

  return (
    <div className="px-6 pt-8 pb-32">
      <header className="flex justify-between items-center mb-8">
        <button 
          onClick={onBack}
          className="p-3 text-[#2d2d5f] hover:bg-indigo-50 rounded-2xl transition-colors"
        >
          <ChevronLeft size={28} />
        </button>
        <h1 className="text-2xl font-black text-[#2d2d5f]">{t.habit_details}</h1>
        <div className="flex gap-2">
          <button 
            onClick={onEdit}
            className="p-3 text-indigo-600 hover:bg-indigo-50 rounded-2xl transition-colors"
          >
            <Edit2 size={24} />
          </button>
          <button 
            onClick={() => {
              if (window.confirm(t.confirm_delete)) {
                onDelete();
              }
            }}
            className="p-3 text-red-500 hover:bg-red-50 rounded-2xl transition-colors"
          >
            <Trash2 size={24} />
          </button>
        </div>
      </header>

      <div className="bg-white rounded-[40px] p-8 shadow-xl shadow-indigo-100 border border-indigo-50 mb-8 flex flex-col items-center text-center">
        <div 
          className="w-20 h-20 rounded-3xl flex items-center justify-center text-white mb-6 shadow-lg"
          style={{ backgroundColor: habit.color }}
        >
          <Target size={40} />
        </div>
        <h2 className="text-3xl font-black text-[#2d2d5f] mb-2">{habit.name}</h2>
        <span className="text-xs font-black text-indigo-400 uppercase tracking-widest bg-indigo-50 px-4 py-1 rounded-full">
          {category?.name || habit.categoryId}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-white rounded-[30px] p-6 shadow-sm border border-indigo-50">
          <div className="text-emerald-500 mb-2">
            <Flame size={24} fill="currentColor" />
          </div>
          <div className="text-2xl font-black text-[#2d2d5f]">{habit.streak}</div>
          <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.daily_streak}</div>
        </div>
        <div className="bg-white rounded-[30px] p-6 shadow-sm border border-indigo-50">
          <div className="text-indigo-500 mb-2">
            <Target size={24} />
          </div>
          <div className="text-2xl font-black text-[#2d2d5f]">{completionRate}%</div>
          <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{t.completion}</div>
        </div>
      </div>

      <div className="bg-white rounded-[40px] p-8 shadow-sm border border-indigo-50 space-y-6 mb-8">
        <CalendarHeatmap 
          completedDates={habit.completedDates} 
          color={habit.color} 
          weeks={5} 
          t={t} 
        />
      </div>

      <div className="bg-white rounded-[40px] p-8 shadow-sm border border-indigo-50 space-y-6 mb-8">
        <h3 className="text-lg font-black text-[#2d2d5f]">{t.frequency}</h3>
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Calendar size={24} />
          </div>
          <div>
            <div className="font-bold text-[#2d2d5f]">
              {habit.frequency === "Günlük" ? t.daily : 
               habit.frequency === "Haftalık" ? t.weekly : 
               habit.frequency === "Aylık" ? t.monthly : 
               t.every_x_days.replace("{x}", habit.reminderDays[0].toString())}
            </div>
            <div className="text-xs text-gray-400">
              {habit.frequency === "Haftalık" && t.days_short.filter((_: any, i: number) => habit.reminderDays.includes(i)).join(", ")}
              {habit.frequency === "Aylık" && `${t.monthly_days}: ${habit.reminderDays.join(", ")}`}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Clock size={24} />
          </div>
          <div>
            <div className="font-bold text-[#2d2d5f]">
              {habit.remindersEnabled ? habit.reminderTime : t.reminders_off}
            </div>
            <div className="text-xs text-gray-400">{t.reminder}</div>
          </div>
        </div>

        {habit.remindersEnabled && (
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Volume2 size={24} />
            </div>
            <div>
              <div className="font-bold text-[#2d2d5f]">
                {REMINDER_SOUNDS.find(s => s.id === habit.reminderSound)?.name || habit.reminderSound}
              </div>
              <div className="text-xs text-gray-400">{t.reminder_sound}</div>
            </div>
          </div>
        )}

        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Target size={24} />
          </div>
          <div>
            <div className="font-bold text-[#2d2d5f]">
              {habit.goalType === "boolean" ? t.boolean_goal : `${habit.targetValue} ${habit.unit}`}
            </div>
            <div className="text-xs text-gray-400">{t.goal_type}</div>
          </div>
        </div>
      </div>

      <div className="bg-indigo-900 text-white rounded-[40px] p-8 shadow-xl">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-black">{t.all_time_stats}</h3>
          <button 
            onClick={onViewHistory}
            className="text-xs font-black text-indigo-300 uppercase tracking-widest bg-white/10 px-4 py-2 rounded-xl hover:bg-white/20 transition-colors"
          >
            {t.see_all}
          </button>
        </div>
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-indigo-200 text-sm">{t.total_completions}</span>
            <span className="text-xl font-black">{totalCompletions}</span>
          </div>
          <div className="w-full h-px bg-indigo-800" />
          <div className="flex justify-between items-center">
            <span className="text-indigo-200 text-sm">{t.best_streak}</span>
            <span className="text-xl font-black">{habit.streak}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
