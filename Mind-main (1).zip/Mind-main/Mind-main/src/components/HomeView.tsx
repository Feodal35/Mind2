import { ReactNode } from "react";
import { Settings, CheckCircle2, Flame, Trophy, Lightbulb, BookOpen, Droplets, Brain, LayoutGrid, Dumbbell, Zap, Moon, Clock } from "lucide-react";
import { motion } from "motion/react";
import { useMemo } from "react";
import { cn } from "@/src/lib/utils";
import type { Habit, Achievement, Category } from "@/src/types";
import type { Language } from "@/src/translations";
import CalendarHeatmap from "./CalendarHeatmap";

const ICON_MAP: Record<string, any> = {
  BookOpen: BookOpen,
  Droplets: Droplets,
  Brain: Brain,
  LayoutGrid: LayoutGrid,
  Dumbbell: Dumbbell,
  Zap: Zap,
  Moon: Moon
};

interface HomeViewProps {
  habits: Habit[];
  categories: Category[];
  toggleHabit: (id: string) => void;
  achievements: Achievement[];
  points: number;
  level: number;
  t: any;
  lang: Language;
  onSeeAllHabits: () => void;
  onGoToSettings: () => void;
  onSelectHabit: (id: string) => void;
  updateHabitProgress: (id: string, amount: number) => void;
}

export default function HomeView({ habits, categories, toggleHabit, achievements, points, level, t, lang, onSeeAllHabits, onGoToSettings, onSelectHabit, updateHabitProgress }: HomeViewProps) {
  const todayStr = new Date().toISOString().split('T')[0];
  const today = new Date();
  const dayOfWeek = today.getDay();
  const dayOfMonth = today.getDate();

  const isHabitDueToday = (habit: Habit) => {
    if (habit.frequency === "Günlük") return true;
    if (habit.frequency === "Haftalık") return habit.reminderDays.includes(dayOfWeek);
    if (habit.frequency === "Aylık") return habit.reminderDays.includes(dayOfMonth);
    if (habit.frequency === "Özel") {
      const created = new Date(habit.createdAt);
      created.setHours(0, 0, 0, 0);
      const current = new Date(today);
      current.setHours(0, 0, 0, 0);
      const diffTime = Math.abs(current.getTime() - created.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays % habit.reminderDays[0] === 0;
    }
    return false;
  };

  const todaysHabits = habits.filter(isHabitDueToday);
  const completedToday = todaysHabits.filter(h => h.completedDates.includes(todayStr)).length;
  const totalHabits = todaysHabits.length;
  const progress = totalHabits > 0 ? Math.round((completedToday / totalHabits) * 100) : 0;

  const maxStreak = useMemo(() => {
    return habits.length > 0 ? Math.max(...habits.map(h => h.streak)) : 0;
  }, [habits]);

  const latestAchievement = useMemo(() => {
    const unlocked = achievements.filter(a => a.unlocked);
    return unlocked.length > 0 ? unlocked[unlocked.length - 1] : achievements[0];
  }, [achievements]);

  const nextHabit = useMemo(() => {
    return todaysHabits.find(h => !h.completedDates.includes(todayStr));
  }, [todaysHabits, todayStr]);

  const currentMonthName = useMemo(() => {
    return new Intl.DateTimeFormat(lang === 'tr' ? 'tr-TR' : 'en-US', { month: 'long', year: 'numeric' }).format(today);
  }, [lang, today]);

  const weekDays = useMemo(() => {
    const days = [];
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1)); // Start from Monday
    
    for (let i = 0; i < 6; i++) {
      const date = new Date(startOfWeek);
      date.setDate(startOfWeek.getDate() + i);
      days.push({
        name: t.days_short[date.getDay()],
        date: date.getDate(),
        current: date.toDateString() === today.toDateString()
      });
    }
    return days;
  }, [t.days_short, today]);

  const allCompletedDates = useMemo(() => {
    const dates = new Set<string>();
    habits.forEach(h => h.completedDates.forEach(d => dates.add(d)));
    return Array.from(dates);
  }, [habits]);

  return (
    <div className="px-6 pt-8 pb-12">
      {/* Header */}
      <header className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center overflow-hidden border-2 border-white shadow-sm">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" 
              alt="Profile" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <span className="text-xl font-bold text-[#4f46e5]">Mindful Flow</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-2xl shadow-sm border border-indigo-50">
            <Zap size={16} className="text-indigo-500" fill="currentColor" />
            <span className="text-sm font-black text-[#2d2d5f]">{points}</span>
            <div className="w-px h-3 bg-gray-200 mx-1" />
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{t.level} {level}</span>
          </div>
          <button 
            onClick={onGoToSettings}
            className="p-2 text-gray-400 hover:text-indigo-600 transition-colors"
          >
            <Settings size={24} />
          </button>
        </div>
      </header>

      <h1 className="text-3xl font-extrabold mb-2 leading-tight">
        {t.hello}
      </h1>
      <p className="text-gray-400 mb-8">{t.subtitle}</p>

      {/* Main Progress Card */}
      <motion.div 
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-indigo-500 rounded-[40px] p-8 text-white relative overflow-hidden mb-8 shadow-xl shadow-indigo-100"
      >
        <div className="relative z-10 flex flex-col items-center">
          <div className="relative w-32 h-32 mb-6">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="64"
                cy="64"
                r="58"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-indigo-400/30"
              />
              <motion.circle
                cx="64"
                cy="64"
                r="58"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={364.4}
                initial={{ strokeDashoffset: 364.4 }}
                animate={{ strokeDashoffset: 364.4 - (364.4 * progress) / 100 }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="text-white"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-black">%{progress}</span>
              <span className="text-[10px] font-bold tracking-widest uppercase opacity-80">{t.completed}</span>
            </div>
          </div>
          <button className="bg-white/20 backdrop-blur-md px-6 py-2 rounded-full text-sm font-bold hover:bg-white/30 transition-colors">
            {t.great_job}
          </button>
        </div>
        {/* Decorative Leaf */}
        <div className="absolute top-4 right-4 opacity-20">
          <svg width="60" height="60" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z" />
          </svg>
        </div>
      </motion.div>

      {/* Global Activity Heatmap */}
      <div className="bg-white rounded-[40px] p-8 mb-8 shadow-sm border border-indigo-50">
        <CalendarHeatmap 
          completedDates={allCompletedDates} 
          color="#6366f1" 
          weeks={5} 
          t={t} 
        />
      </div>

      {/* Weekly View */}
      <div className="bg-white rounded-3xl p-6 mb-8 shadow-sm border border-gray-50">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold text-lg">{t.weekly_view}</h3>
          <span className="text-indigo-500 text-sm font-bold capitalize">{currentMonthName}</span>
        </div>
        <div className="flex justify-between">
          {weekDays.map((day, i) => (
            <div key={i} className="flex flex-col items-center gap-2">
              <span className="text-[10px] font-bold text-gray-400">{day.name}</span>
              <div className={cn(
                "w-10 h-14 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all",
                day.current ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "bg-indigo-50 text-indigo-900"
              )}>
                <span className="text-sm font-bold">{day.date}</span>
                <div className={cn("w-1 h-1 rounded-full", day.current ? "bg-white" : "bg-indigo-400")} />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Motivation Quote */}
      <div className="bg-indigo-50 rounded-3xl p-6 mb-8 relative overflow-hidden">
        <div className="flex gap-4 items-start">
          <div className="bg-indigo-200 p-3 rounded-2xl text-indigo-600">
            <Lightbulb size={24} />
          </div>
          <div>
            <p className="text-sm italic text-indigo-900/80 mb-2 leading-relaxed">
              "{t.motivation_quote}"
            </p>
            <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">— {t.motivation_title}</span>
          </div>
        </div>
        <div className="absolute -bottom-4 -right-2 opacity-10 text-indigo-600">
          <svg width="80" height="80" viewBox="0 0 24 24" fill="currentColor">
            <path d="M14,17H17L19,13V7H13V13H16L14,17M6,17H9L11,13V7H5V13H8L6,17Z" />
          </svg>
        </div>
      </div>

      {/* Today's Habits */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <h3 className="font-bold text-xl">{t.todays_habits}</h3>
            {totalHabits > 0 && (
              <span className="bg-indigo-100 text-indigo-600 text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-widest">
                {completedToday}/{totalHabits}
              </span>
            )}
          </div>
          <button 
            onClick={onSeeAllHabits}
            className="text-indigo-500 text-sm font-bold"
          >
            {t.see_all}
          </button>
        </div>

        {nextHabit && (
          <motion.div 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="bg-white rounded-[32px] p-6 mb-6 border-2 border-indigo-100 shadow-sm relative overflow-hidden group"
            onClick={() => onSelectHabit(nextHabit.id)}
          >
            <div className="absolute top-0 right-0 bg-indigo-100 text-indigo-600 px-4 py-1 rounded-bl-2xl text-[10px] font-black uppercase tracking-widest">
              {t.next_up || "SIRADAKİ"}
            </div>
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-100">
                {(() => {
                  const Icon = ICON_MAP[nextHabit.icon] || BookOpen;
                  return <Icon size={28} />;
                })()}
              </div>
              <div className="flex-1">
                <h4 className="font-black text-lg text-[#2d2d5f]">{nextHabit.name}</h4>
                <p className="text-xs text-gray-400 font-bold uppercase tracking-widest flex items-center gap-1">
                  <Clock size={12} /> {nextHabit.reminderTime}
                </p>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  toggleHabit(nextHabit.id);
                }}
                className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center hover:bg-indigo-600 hover:text-white transition-all"
              >
                <CheckCircle2 size={24} />
              </button>
            </div>
          </motion.div>
        )}

        <div className="space-y-4">
          {todaysHabits.map(habit => (
            <HabitCard 
              key={habit.id} 
              habit={habit} 
              category={categories.find(c => c.id === habit.categoryId)}
              isCompleted={habit.completedDates.includes(todayStr)}
              onToggle={() => toggleHabit(habit.id)}
              onUpdateProgress={(amount) => updateHabitProgress(habit.id, amount)}
              onClick={() => onSelectHabit(habit.id)}
              t={t}
            />
          ))}
          {todaysHabits.length === 0 && (
            <div className="bg-white rounded-[40px] p-12 text-center border-2 border-dashed border-gray-100">
              <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                <LayoutGrid size={32} />
              </div>
              <h4 className="font-bold text-[#2d2d5f] mb-2">{t.no_habits_today || "Bugün için alışkanlık bulunmuyor."}</h4>
              <p className="text-xs text-gray-400 mb-6">{t.no_habits_desc || "Yeni bir alışkanlık edinerek değişime hemen başla!"}</p>
              <button 
                onClick={() => onSeeAllHabits()}
                className="bg-indigo-500 text-white px-8 py-3 rounded-2xl font-black text-sm shadow-lg shadow-indigo-100"
              >
                {t.add_habit}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Streak and Badge Cards */}
      <div className="space-y-4">
        <div className="bg-[#1a1a3a] text-white rounded-3xl p-6 flex items-center gap-4 shadow-xl">
          <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Flame size={28} fill="currentColor" />
          </div>
          <div>
            <h4 className="font-bold text-lg">{t.streak_title}</h4>
            <p className="text-sm text-gray-400">
              {t.streak_desc.replace("{days}", maxStreak.toString()).replace("{next}", (maxStreak + 1).toString())}
            </p>
          </div>
          <div className="ml-auto text-2xl font-black text-indigo-400">{maxStreak}</div>
        </div>

        {latestAchievement && (
          <div className={cn(
            "rounded-3xl p-6 flex items-center gap-4 shadow-xl transition-all",
            latestAchievement.unlocked ? "bg-[#065f46] text-white" : "bg-gray-100 text-gray-500"
          )}>
            <div className={cn(
              "w-12 h-12 rounded-full flex items-center justify-center",
              latestAchievement.unlocked ? "bg-emerald-500/20 text-emerald-400" : "bg-gray-200 text-gray-400"
            )}>
              <Trophy size={28} />
            </div>
            <div>
              <h4 className="font-bold text-lg">{latestAchievement.unlocked ? t.new_badge_title : t.achievements}</h4>
              <p className={cn(
                "text-sm",
                latestAchievement.unlocked ? "text-emerald-100/70" : "text-gray-400"
              )}>
                {t.achievements_list?.[latestAchievement.title] || latestAchievement.title}: {t.achievements_list?.[latestAchievement.description] || latestAchievement.description}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function HabitCard({ habit, category, isCompleted, onToggle, onUpdateProgress, onClick, t }: { habit: Habit, category?: Category, isCompleted: boolean, onToggle: () => void, onUpdateProgress: (amount: number) => void, onClick: () => void, t: any, key?: string }) {
  const IconComponent = ICON_MAP[habit.icon] || BookOpen;
  const todayStr = new Date().toISOString().split('T')[0];
  const progress = (habit.dailyProgress || {})[todayStr] || 0;
  const target = habit.targetValue || 1;
  const progressPercent = Math.min(100, (progress / target) * 100);

  return (
    <motion.div 
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="bg-white rounded-3xl p-5 flex flex-col gap-4 shadow-sm border border-gray-50 cursor-pointer"
    >
      <div className="flex items-center gap-4">
        <div className={cn(
          "w-12 h-12 rounded-2xl flex items-center justify-center",
          isCompleted ? "bg-emerald-50 text-emerald-600" : "bg-indigo-50 text-indigo-600"
        )}>
          <IconComponent size={24} />
        </div>
        <div className="flex-1">
          <h4 className={cn("font-bold text-lg", isCompleted && "text-gray-400 line-through")}>{habit.name}</h4>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
              {category?.name?.toUpperCase() || habit.categoryId?.toUpperCase() || ""}
            </span>
            <div className="w-1 h-1 rounded-full bg-gray-300" />
            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest flex items-center gap-1">
              <Clock size={10} /> {habit.reminderTime}
            </span>
            <div className="w-1 h-1 rounded-full bg-gray-300" />
            <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest bg-emerald-50 px-2 py-0.5 rounded-full">
              {habit.frequency === "Günlük" ? t.daily : 
               habit.frequency === "Haftalık" ? t.weekly : 
               habit.frequency === "Aylık" ? t.monthly : 
               t.every_x_days.replace("{x}", habit.reminderDays[0].toString())}
            </span>
            <div className="w-1 h-1 rounded-full bg-gray-300" />
            <span className="text-[10px] font-black text-orange-500 uppercase tracking-widest flex items-center gap-1">
              <Flame size={10} fill="currentColor" /> {habit.streak} {t.streak}
            </span>
          </div>
        </div>
        
        {habit.goalType === "boolean" ? (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onToggle();
            }}
            className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center transition-all",
              isCompleted ? "bg-emerald-600 text-white" : "border-2 border-gray-100 text-gray-200"
            )}
          >
            <CheckCircle2 size={24} />
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onUpdateProgress(-1);
              }}
              className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-black"
            >
              -
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onUpdateProgress(1);
              }}
              className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center font-black",
                isCompleted ? "bg-emerald-600 text-white" : "bg-indigo-600 text-white"
              )}
            >
              +
            </button>
          </div>
        )}
      </div>

      {habit.goalType === "numeric" && (
        <div className="space-y-2">
          <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest">
            <span className="text-gray-400">{t.progress}: {progress} / {target} {habit.unit}</span>
            <span className={cn(isCompleted ? "text-emerald-500" : "text-indigo-400")}>{progressPercent}%</span>
          </div>
          <div className="w-full h-2 bg-indigo-50 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progressPercent}%` }}
              className={cn("h-full", isCompleted ? "bg-emerald-500" : "bg-indigo-500")}
            />
          </div>
        </div>
      )}
    </motion.div>
  );
}
