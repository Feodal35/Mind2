import { useMemo } from "react";
import { motion } from "motion/react";
import { ChevronLeft, Calendar, Trophy, Zap, Activity } from "lucide-react";
import { cn } from "@/src/lib/utils";
import type { Habit, Category } from "@/src/types";
import * as d3 from "d3";

interface HabitHistoryViewProps {
  habit: Habit;
  category?: Category;
  onBack: () => void;
  t: any;
}

export default function HabitHistoryView({ habit, category, onBack, t }: HabitHistoryViewProps) {
  const stats = useMemo(() => {
    const total = habit.completedDates.length;
    const bestStreak = habit.streak; // Simplified, in a real app we'd calculate the historical max
    
    // Calculate completion rate since creation
    const createdDate = new Date(habit.createdAt);
    const today = new Date();
    const diffTime = Math.abs(today.getTime() - createdDate.getTime());
    const totalDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
    const rate = Math.round((total / totalDays) * 100);

    return { total, bestStreak, rate };
  }, [habit]);

  const heatmapMonths = useMemo(() => {
    const months = [];
    const now = new Date();
    
    // Show last 6 months
    for (let i = 5; i >= 0; i--) {
      const monthDate = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthName = new Intl.DateTimeFormat('default', { month: 'long' }).format(monthDate);
      
      const daysInMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0).getDate();
      const firstDayOfMonth = monthDate.getDay(); // 0 (Sun) to 6 (Sat)
      
      const days = [];
      // Add empty slots for the first week
      for (let j = 0; j < firstDayOfMonth; j++) {
        days.push(null);
      }
      
      for (let j = 1; j <= daysInMonth; j++) {
        const date = new Date(monthDate.getFullYear(), monthDate.getMonth(), j);
        const dateStr = date.toISOString().split('T')[0];
        days.push({
          day: j,
          dateStr,
          isCompleted: habit.completedDates.includes(dateStr),
          isToday: dateStr === now.toISOString().split('T')[0],
          isFuture: date > now
        });
      }
      
      months.push({ name: monthName, days, year: monthDate.getFullYear() });
    }
    
    return months;
  }, [habit.completedDates]);

  return (
    <div className="px-6 pt-8 pb-12">
      <header className="flex items-center gap-4 mb-8">
        <button 
          onClick={onBack}
          className="w-10 h-10 rounded-full bg-white shadow-sm border border-gray-100 flex items-center justify-center text-[#2d2d5f]"
        >
          <ChevronLeft size={24} />
        </button>
        <div>
          <h1 className="text-2xl font-black leading-tight">{t.habit_history}</h1>
          <p className="text-gray-400 text-xs font-bold uppercase tracking-widest">{habit.name}</p>
        </div>
      </header>

      {/* Stats Summary */}
      <div className="grid grid-cols-3 gap-4 mb-10">
        <StatCard 
          icon={<Activity size={18} />} 
          label={t.total_completions} 
          value={stats.total} 
          color="text-indigo-600"
          bgColor="bg-indigo-50"
        />
        <StatCard 
          icon={<Trophy size={18} />} 
          label={t.best_streak} 
          value={stats.bestStreak} 
          color="text-emerald-600"
          bgColor="bg-emerald-50"
        />
        <StatCard 
          icon={<Zap size={18} />} 
          label={t.completion_rate} 
          value={`%${stats.rate}`} 
          color="text-amber-600"
          bgColor="bg-amber-50"
        />
      </div>

      {/* Detailed History Heatmap */}
      <div className="space-y-10">
        {heatmapMonths.map((month, idx) => (
          <div key={`${month.name}-${month.year}`} className="bg-white rounded-[32px] p-6 shadow-sm border border-gray-50">
            <h3 className="text-sm font-black text-[#2d2d5f] mb-4 uppercase tracking-widest flex justify-between">
              <span>{month.name}</span>
              <span className="text-gray-300">{month.year}</span>
            </h3>
            
            <div className="grid grid-cols-7 gap-2">
              {/* Day Labels */}
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
                <div key={i} className="text-[8px] font-black text-gray-300 text-center mb-2">{d}</div>
              ))}
              
              {month.days.map((day, i) => (
                <div 
                  key={i}
                  className={cn(
                    "aspect-square rounded-lg flex items-center justify-center text-[10px] font-bold transition-all",
                    !day ? "bg-transparent" : 
                    day.isFuture ? "bg-gray-50 text-gray-200" :
                    day.isCompleted ? "text-white shadow-sm" : "bg-gray-50 text-gray-400",
                    day?.isToday && "ring-2 ring-indigo-200"
                  )}
                  style={{ 
                    backgroundColor: day?.isCompleted && !day.isFuture ? (category?.color || "#6366f1") : undefined 
                  }}
                >
                  {day?.day}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {habit.completedDates.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-400 font-bold italic">{t.no_history}</p>
        </div>
      )}
    </div>
  );
}

function StatCard({ icon, label, value, color, bgColor }: { icon: any, label: string, value: string | number, color: string, bgColor: string }) {
  return (
    <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-50 flex flex-col items-center text-center gap-2">
      <div className={cn("w-10 h-10 rounded-2xl flex items-center justify-center shadow-sm", bgColor, color)}>
        {icon}
      </div>
      <div>
        <div className="text-lg font-black text-[#2d2d5f]">{value}</div>
        <div className="text-[8px] font-black text-gray-400 uppercase tracking-widest leading-tight">{label}</div>
      </div>
    </div>
  );
}
