import { useMemo } from "react";
import * as d3 from "d3";
import { cn } from "@/src/lib/utils";

interface CalendarHeatmapProps {
  completedDates: string[]; // YYYY-MM-DD
  color?: string;
  weeks?: number;
  t: any;
}

export default function CalendarHeatmap({ completedDates, color = "#6366f1", weeks = 5, t }: CalendarHeatmapProps) {
  const days = weeks * 7;
  
  const heatmapData = useMemo(() => {
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    
    // Find the current day of week (0-6)
    const currentDayOfWeek = now.getDay();
    
    // Offset to start from the beginning of the week (Sunday)
    // We want to show 'weeks' full weeks ending with the current week
    const totalDays = days;
    // Start from the Sunday of 'weeks' ago
    const startDate = d3.timeDay.offset(now, - (totalDays - 1 - (6 - currentDayOfWeek)));
    
    // Actually, let's just show the last 'days' days ending today
    const simpleStartDate = d3.timeDay.offset(now, - (totalDays - 1));

    return d3.range(totalDays).map(i => {
      const date = d3.timeDay.offset(simpleStartDate, i);
      const dateStr = date.toISOString().split('T')[0];
      const isToday = date.getTime() === now.getTime();
      const isFuture = date.getTime() > now.getTime();
      
      return {
        date,
        dateStr,
        isCompleted: completedDates.includes(dateStr),
        isToday,
        isFuture,
        dayOfWeek: date.getDay()
      };
    });
  }, [completedDates, days]);

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">{t.activity_heatmap}</h4>
        <span className="text-[10px] font-bold text-indigo-400 bg-indigo-50 px-2 py-0.5 rounded-full">
          {t.last_weeks.replace("{x}", weeks.toString())}
        </span>
      </div>
      
      <div className="grid grid-cols-7 gap-1.5">
        {/* Day Labels */}
        {t.days_short.map((day: string) => (
          <div key={day} className="text-[8px] font-black text-gray-300 text-center uppercase mb-1">
            {day[0]}
          </div>
        ))}
        
        {/* Heatmap Grid */}
        {heatmapData.map((item) => (
          <div
            key={item.dateStr}
            className={cn(
              "aspect-square rounded-md transition-all duration-500 border border-transparent relative group",
              item.isFuture ? "opacity-10 bg-gray-100" : "bg-indigo-50/50",
              item.isToday && "border-indigo-300 ring-1 ring-indigo-100 ring-offset-1"
            )}
            style={{ 
              backgroundColor: item.isCompleted && !item.isFuture ? color : undefined,
              opacity: item.isCompleted && !item.isFuture ? 1 : undefined
            }}
          >
            {/* Tooltip on hover */}
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#2d2d5f] text-white text-[8px] rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-10 shadow-xl">
              {item.dateStr} {item.isCompleted ? "✓" : ""}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
