import { useState, ReactNode } from "react";
import { Settings, LogOut, Shield, Bell, ChevronRight, Flame, Trophy, Target, Globe, LayoutGrid, Zap, Brain, Droplets } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "@/src/lib/utils";
import type { Habit, Achievement } from "@/src/types";
import type { Language } from "@/src/translations";

import { notificationService } from "@/src/lib/notificationService";

interface ProfileViewProps {
  habits: Habit[];
  points: number;
  level: number;
  achievements: Achievement[];
  t: any;
  lang: Language;
  setLang: (lang: Language) => void;
  onManageCategories: () => void;
  onResetData: () => void;
}

export default function ProfileView({ habits, points, level, achievements, t, lang, setLang, onManageCategories, onResetData }: ProfileViewProps) {
  const [activeSubView, setActiveSubView] = useState<"privacy" | "notifications" | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const handleRequestPermission = async () => {
    const granted = await notificationService.requestPermission();
    setNotificationPermission(granted ? 'granted' : 'denied');
  };

  const handleTestNotification = () => {
    if (habits.length > 0) {
      notificationService.scheduleNotification(habits[0], t);
    } else {
      // If no habits, send a generic test
      new Notification(t.habit_reminder, {
        body: t.notification_sent,
        icon: "/favicon.ico"
      });
    }
  };

  const totalStreaks = habits.reduce((acc, h) => acc + h.streak, 0);
  const totalHabits = habits.length;
  const unlockedCount = achievements.filter(a => a.unlocked).length;

  if (activeSubView === "notifications") {
    return (
      <div className="px-6 pt-8 pb-12">
        <header className="flex items-center gap-4 mb-12">
          <button 
            onClick={() => setActiveSubView(null)}
            className="p-2 text-gray-400 hover:text-indigo-600 transition-colors"
          >
            <ChevronRight size={24} className="rotate-180" />
          </button>
          <h1 className="text-3xl font-black text-[#2d2d5f]">{t.notifications}</h1>
        </header>

        <div className="space-y-8">
          <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-50">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-6">
              <Bell size={24} />
            </div>
            <h3 className="text-xl font-black text-[#2d2d5f] mb-2">{t.notification_permission}</h3>
            <p className="text-sm text-gray-400 mb-6">
              {notificationPermission === 'granted' 
                ? t.reminders_on 
                : notificationPermission === 'denied' 
                  ? t.reminders_off 
                  : t.notification_permission_desc}
            </p>

            {notificationPermission !== 'granted' ? (
              <button 
                onClick={handleRequestPermission}
                className="w-full bg-indigo-600 text-white rounded-2xl py-4 font-black shadow-lg shadow-indigo-100"
              >
                {t.allow}
              </button>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                  <span className="text-emerald-700 font-bold text-sm">{t.reminders_on}</span>
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </div>
                <button 
                  onClick={handleTestNotification}
                  className="w-full bg-white border-2 border-indigo-100 text-indigo-600 rounded-2xl py-4 font-black hover:bg-indigo-50 transition-colors"
                >
                  {t.test_sound}
                </button>
              </div>
            )}
          </div>

          <div className="bg-indigo-50 rounded-[40px] p-8 border border-indigo-100">
            <h4 className="font-black text-[#2d2d5f] mb-2 text-sm uppercase tracking-widest">{t.reminder_time}</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              {t.notification_permission_desc}
            </p>
          </div>

          <button 
            onClick={() => setActiveSubView(null)}
            className="w-full bg-indigo-600 text-white rounded-3xl py-4 font-black shadow-lg shadow-indigo-100"
          >
            {t.back_to_profile}
          </button>
        </div>
      </div>
    );
  }

  if (activeSubView === "privacy") {
    return (
      <div className="px-6 pt-8 pb-12">
        <header className="flex items-center gap-4 mb-12">
          <button 
            onClick={() => setActiveSubView(null)}
            className="p-2 text-gray-400 hover:text-indigo-600 transition-colors"
          >
            <ChevronRight size={24} className="rotate-180" />
          </button>
          <h1 className="text-3xl font-black text-[#2d2d5f]">{t.privacy}</h1>
        </header>

        <div className="space-y-8">
          <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-50">
            <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mb-6">
              <Shield size={24} />
            </div>
            <h3 className="text-xl font-black text-[#2d2d5f] mb-4">{t.privacy_policy}</h3>
            <p className="text-gray-400 leading-relaxed">{t.privacy_desc}</p>
          </div>

          <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-50">
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-6">
              <Shield size={24} />
            </div>
            <h3 className="text-xl font-black text-[#2d2d5f] mb-4">{t.security_settings}</h3>
            <p className="text-gray-400 leading-relaxed">{t.security_desc}</p>
          </div>

          <button 
            onClick={() => setActiveSubView(null)}
            className="w-full bg-indigo-600 text-white rounded-3xl py-4 font-black shadow-lg shadow-indigo-100"
          >
            {t.back_to_profile}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-6 pt-8 pb-12">
      <header className="flex justify-between items-center mb-12">
        <h1 className="text-4xl font-black text-[#2d2d5f]">{t.profile}</h1>
        <button className="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
          <Settings size={24} />
        </button>
      </header>

      {/* User Card */}
      <div className="flex flex-col items-center mb-12">
        <div className="relative mb-6">
          <div className="w-32 h-32 rounded-full bg-indigo-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-xl">
            <img 
              src="https://api.dicebear.com/7.x/avataaars/svg?seed=Mindful" 
              alt="Profile" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute bottom-0 right-0 w-10 h-10 bg-emerald-500 text-white rounded-full border-4 border-white flex items-center justify-center shadow-lg">
            <Flame size={20} fill="currentColor" />
          </div>
        </div>
        <h2 className="text-3xl font-black text-[#2d2d5f] mb-1">Mindful Flow</h2>
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-indigo-500 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
            {t.level} {level}
          </span>
          <span className="bg-emerald-50 text-emerald-600 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
            {points} {t.points}
          </span>
        </div>
        <p className="text-gray-400 font-bold">{t.premium}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-3 gap-4 mb-12">
        <StatItem label={t.streak} value={totalStreaks} icon={<Flame size={20} />} color="text-orange-500" bgColor="bg-orange-50" />
        <StatItem label={t.habits} value={totalHabits} icon={<Target size={20} />} color="text-indigo-500" bgColor="bg-indigo-50" />
        <StatItem label={t.badges} value={unlockedCount} icon={<Trophy size={20} />} color="text-emerald-500" bgColor="bg-emerald-50" />
      </div>

      {/* Settings List */}
      <div className="space-y-4">
        <h3 className="text-xl font-black text-[#2d2d5f] mb-6">{t.account_settings}</h3>
        
        {/* Language Switcher */}
        <div className="bg-white rounded-[32px] p-2 shadow-sm border border-gray-50 flex items-center mb-4">
          <button 
            onClick={() => setLang("tr")}
            className={cn(
              "flex-1 py-3 px-4 rounded-3xl text-sm font-bold transition-all flex items-center justify-center gap-2",
              lang === "tr" ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "text-gray-400"
            )}
          >
            <Globe size={16} />
            {t.turkish}
          </button>
          <button 
            onClick={() => setLang("en")}
            className={cn(
              "flex-1 py-3 px-4 rounded-3xl text-sm font-bold transition-all flex items-center justify-center gap-2",
              lang === "en" ? "bg-indigo-600 text-white shadow-lg shadow-indigo-100" : "text-gray-400"
            )}
          >
            <Globe size={16} />
            {t.english}
          </button>
        </div>

        <SettingsItem icon={<LayoutGrid size={20} />} label={t.manage_categories} onClick={onManageCategories} />
        <SettingsItem icon={<Bell size={20} />} label={t.notifications} onClick={() => setActiveSubView("notifications")} />
        <SettingsItem icon={<Shield size={20} />} label={t.privacy} onClick={() => setActiveSubView("privacy")} />
        
        <SettingsItem 
          icon={<LogOut size={20} />} 
          label={t.reset_data} 
          color="text-red-500" 
          onClick={onResetData}
        />
      </div>

      {/* Badges Section */}
      <div className="mt-12">
        <h3 className="text-xl font-black text-[#2d2d5f] mb-6">{t.achievements}</h3>
        <div className="grid grid-cols-2 gap-4">
          {achievements.map((achievement) => (
            <div 
              key={achievement.id}
              className={cn(
                "p-6 rounded-[32px] border flex flex-col items-center text-center gap-3 transition-all",
                achievement.unlocked 
                  ? "bg-white border-indigo-100 shadow-sm" 
                  : "bg-gray-50 border-transparent opacity-60 grayscale"
              )}
            >
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center shadow-sm",
                achievement.unlocked ? "bg-indigo-50 text-indigo-600" : "bg-white text-gray-300"
              )}>
                {achievement.icon === "Trophy" ? <Trophy size={24} /> : 
                 achievement.icon === "Droplets" ? <Droplets size={24} /> : 
                 achievement.icon === "Brain" ? <Brain size={24} /> : 
                 <Zap size={24} />}
              </div>
              <div>
                <h4 className="text-xs font-black text-[#2d2d5f] uppercase tracking-wider mb-1">
                  {t.achievements_list?.[achievement.title] || achievement.title}
                </h4>
                <p className="text-[10px] text-gray-400 font-bold leading-tight">
                  {t.achievements_list?.[achievement.description] || achievement.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatItem({ label, value, icon, color, bgColor }: { label: string, value: number, icon: ReactNode, color: string, bgColor: string }) {
  return (
    <div className="bg-white rounded-[30px] p-4 flex flex-col items-center gap-2 shadow-sm border border-gray-50">
      <div className={cn("w-10 h-10 rounded-2xl flex items-center justify-center", bgColor, color)}>
        {icon}
      </div>
      <span className="text-2xl font-black text-[#2d2d5f]">{value}</span>
      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{label}</span>
    </div>
  );
}

function SettingsItem({ icon, label, color = "text-[#2d2d5f]", onClick }: { icon: ReactNode, label: string, color?: string, onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className="w-full bg-white rounded-[30px] p-6 flex items-center gap-4 shadow-sm border border-gray-50 hover:bg-indigo-50/30 transition-colors group"
    >
      <div className={cn("w-12 h-12 rounded-2xl bg-gray-50 flex items-center justify-center group-hover:bg-white transition-colors", color)}>
        {icon}
      </div>
      <span className={cn("flex-1 text-left font-bold text-lg", color)}>{label}</span>
      <ChevronRight size={20} className="text-gray-300" />
    </button>
  );
}
