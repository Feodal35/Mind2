import { useState, useEffect, ReactNode, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Home as HomeIcon, 
  LayoutList, 
  BarChart3, 
  User, 
  Plus, 
  Settings,
  Bell,
  CheckCircle2,
  Flame,
  Trophy,
  Droplets,
  BookOpen,
  Brain,
  Zap,
  Dumbbell,
  Moon,
  ChevronLeft,
  Clock
} from "lucide-react";
import { cn } from "@/src/lib/utils";
import type { Habit, Category, Achievement } from "@/src/types";
import { translations, type Language } from "@/src/translations";
import { notificationService } from "@/src/lib/notificationService";

// Views
import HomeView from "./components/HomeView";
import HabitsView from "./components/HabitsView";
import StatsView from "./components/StatsView";
import ProfileView from "./components/ProfileView";
import AddHabitView from "./components/AddHabitView";
import CategoriesView from "./components/CategoriesView";
import HabitDetailsView from "./components/HabitDetailsView";
import HabitHistoryView from "./components/HabitHistoryView";

const DEFAULT_CATEGORIES: Category[] = [
  { id: "health", name: "Sağlık", icon: "Droplets", color: "#3b82f6" },
  { id: "mind", name: "Zihin", icon: "Brain", color: "#8b5cf6" },
  { id: "productivity", name: "Üretkenlik", icon: "Zap", color: "#f59e0b" },
  { id: "growth", name: "Kişisel Gelişim", icon: "BookOpen", color: "#6366f1" },
];

const INITIAL_HABITS: Habit[] = [];

const ACHIEVEMENTS: Achievement[] = [
  // Points (15)
  { id: "p1", title: "p1_title", icon: "Zap", description: "p1_desc", unlocked: false, requirementType: "points", requirementValue: 100 },
  { id: "p2", title: "p2_title", icon: "Zap", description: "p2_desc", unlocked: false, requirementType: "points", requirementValue: 250 },
  { id: "p3", title: "p3_title", icon: "Zap", description: "p3_desc", unlocked: false, requirementType: "points", requirementValue: 500 },
  { id: "p4", title: "p4_title", icon: "Zap", description: "p4_desc", unlocked: false, requirementType: "points", requirementValue: 1000 },
  { id: "p5", title: "p5_title", icon: "Zap", description: "p5_desc", unlocked: false, requirementType: "points", requirementValue: 2000 },
  { id: "p6", title: "p6_title", icon: "Zap", description: "p6_desc", unlocked: false, requirementType: "points", requirementValue: 3000 },
  { id: "p7", title: "p7_title", icon: "Zap", description: "p7_desc", unlocked: false, requirementType: "points", requirementValue: 4000 },
  { id: "p8", title: "p8_title", icon: "Zap", description: "p8_desc", unlocked: false, requirementType: "points", requirementValue: 5000 },
  { id: "p9", title: "p9_title", icon: "Zap", description: "p9_desc", unlocked: false, requirementType: "points", requirementValue: 7500 },
  { id: "p10", title: "p10_title", icon: "Zap", description: "p10_desc", unlocked: false, requirementType: "points", requirementValue: 10000 },
  { id: "p11", title: "p11_title", icon: "Zap", description: "p11_desc", unlocked: false, requirementType: "points", requirementValue: 20000 },
  { id: "p12", title: "p12_title", icon: "Zap", description: "p12_desc", unlocked: false, requirementType: "points", requirementValue: 30000 },
  { id: "p13", title: "p13_title", icon: "Zap", description: "p13_desc", unlocked: false, requirementType: "points", requirementValue: 40000 },
  { id: "p14", title: "p14_title", icon: "Zap", description: "p14_desc", unlocked: false, requirementType: "points", requirementValue: 50000 },
  { id: "p15", title: "p15_title", icon: "Zap", description: "p15_desc", unlocked: false, requirementType: "points", requirementValue: 100000 },

  // Streaks (15)
  { id: "s1", title: "s1_title", icon: "Flame", description: "s1_desc", unlocked: false, requirementType: "streak", requirementValue: 3 },
  { id: "s2", title: "s2_title", icon: "Flame", description: "s2_desc", unlocked: false, requirementType: "streak", requirementValue: 5 },
  { id: "s3", title: "s3_title", icon: "Flame", description: "s3_desc", unlocked: false, requirementType: "streak", requirementValue: 7 },
  { id: "s4", title: "s4_title", icon: "Flame", description: "s4_desc", unlocked: false, requirementType: "streak", requirementValue: 10 },
  { id: "s5", title: "s5_title", icon: "Flame", description: "s5_desc", unlocked: false, requirementType: "streak", requirementValue: 14 },
  { id: "s6", title: "s6_title", icon: "Flame", description: "s6_desc", unlocked: false, requirementType: "streak", requirementValue: 21 },
  { id: "s7", title: "s7_title", icon: "Flame", description: "s7_desc", unlocked: false, requirementType: "streak", requirementValue: 30 },
  { id: "s8", title: "s8_title", icon: "Flame", description: "s8_desc", unlocked: false, requirementType: "streak", requirementValue: 45 },
  { id: "s9", title: "s9_title", icon: "Flame", description: "s9_desc", unlocked: false, requirementType: "streak", requirementValue: 60 },
  { id: "s10", title: "s10_title", icon: "Flame", description: "s10_desc", unlocked: false, requirementType: "streak", requirementValue: 75 },
  { id: "s11", title: "s11_title", icon: "Flame", description: "s11_desc", unlocked: false, requirementType: "streak", requirementValue: 90 },
  { id: "s12", title: "s12_title", icon: "Flame", description: "s12_desc", unlocked: false, requirementType: "streak", requirementValue: 100 },
  { id: "s13", title: "s13_title", icon: "Flame", description: "s13_desc", unlocked: false, requirementType: "streak", requirementValue: 150 },
  { id: "s14", title: "s14_title", icon: "Flame", description: "s14_desc", unlocked: false, requirementType: "streak", requirementValue: 200 },
  { id: "s15", title: "s15_title", icon: "Flame", description: "s15_desc", unlocked: false, requirementType: "streak", requirementValue: 365 },

  // Completions (15)
  { id: "c1", title: "c1_title", icon: "Trophy", description: "c1_desc", unlocked: false, requirementType: "completions", requirementValue: 5 },
  { id: "c2", title: "c2_title", icon: "Trophy", description: "c2_desc", unlocked: false, requirementType: "completions", requirementValue: 10 },
  { id: "c3", title: "c3_title", icon: "Trophy", description: "c3_desc", unlocked: false, requirementType: "completions", requirementValue: 20 },
  { id: "c4", title: "c4_title", icon: "Trophy", description: "c4_desc", unlocked: false, requirementType: "completions", requirementValue: 30 },
  { id: "c5", title: "c5_title", icon: "Trophy", description: "c5_desc", unlocked: false, requirementType: "completions", requirementValue: 40 },
  { id: "c6", title: "c6_title", icon: "Trophy", description: "c6_desc", unlocked: false, requirementType: "completions", requirementValue: 50 },
  { id: "c7", title: "c7_title", icon: "Trophy", description: "c7_desc", unlocked: false, requirementType: "completions", requirementValue: 75 },
  { id: "c8", title: "c8_title", icon: "Trophy", description: "c8_desc", unlocked: false, requirementType: "completions", requirementValue: 100 },
  { id: "c9", title: "c9_title", icon: "Trophy", description: "c9_desc", unlocked: false, requirementType: "completions", requirementValue: 150 },
  { id: "c10", title: "c10_title", icon: "Trophy", description: "c10_desc", unlocked: false, requirementType: "completions", requirementValue: 200 },
  { id: "c11", title: "c11_title", icon: "Trophy", description: "c11_desc", unlocked: false, requirementType: "completions", requirementValue: 250 },
  { id: "c12", title: "c12_title", icon: "Trophy", description: "c12_desc", unlocked: false, requirementType: "completions", requirementValue: 300 },
  { id: "c13", title: "c13_title", icon: "Trophy", description: "c13_desc", unlocked: false, requirementType: "completions", requirementValue: 400 },
  { id: "c14", title: "c14_title", icon: "Trophy", description: "c14_desc", unlocked: false, requirementType: "completions", requirementValue: 500 },
  { id: "c15", title: "c15_title", icon: "Trophy", description: "c15_desc", unlocked: false, requirementType: "completions", requirementValue: 1000 },

  // Hardcore (5)
  { id: "h1", title: "h1_title", icon: "Flame", description: "h1_desc", unlocked: false, requirementType: "streak", requirementValue: 500 },
  { id: "h2", title: "h2_title", icon: "Flame", description: "h2_desc", unlocked: false, requirementType: "streak", requirementValue: 1000 },
  { id: "h3", title: "h3_title", icon: "Trophy", description: "h3_desc", unlocked: false, requirementType: "completions", requirementValue: 5000 },
  { id: "h4", title: "h4_title", icon: "Zap", description: "h4_desc", unlocked: false, requirementType: "points", requirementValue: 500000 },
  { id: "h5", title: "h5_title", icon: "Zap", description: "h5_desc", unlocked: false, requirementType: "points", requirementValue: 1000000 },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "habits" | "stats" | "profile" | "add" | "categories" | "details" | "history">("home");
  const [selectedHabitId, setSelectedHabitId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [points, setPoints] = useState<number>(() => {
    const saved = localStorage.getItem("mindful_flow_v2_points");
    return saved ? parseInt(saved) : 0;
  });
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem("mindful_flow_v2_lang");
    return (saved as Language) || "tr";
  });
  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem("mindful_flow_v2_categories");
    return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
  });
  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem("mindful_flow_v2_habits");
    return saved ? JSON.parse(saved) : INITIAL_HABITS;
  });
  const habitsRef = useRef(habits);
  habitsRef.current = habits;

  const t = translations[lang];

  useEffect(() => {
    localStorage.setItem("mindful_flow_v2_habits", JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem("mindful_flow_v2_categories", JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem("mindful_flow_v2_lang", lang);
  }, [lang]);

  useEffect(() => {
    localStorage.setItem("mindful_flow_v2_points", points.toString());
  }, [points]);

  const level = Math.floor(points / 200) + 1;
  const pointsToNextLevel = (level * 200) - points;
  const levelProgress = ((points % 200) / 200) * 100;

  const unlockedAchievements = useMemo(() => {
    return ACHIEVEMENTS.map(achievement => {
      let isUnlocked = false;
      if (achievement.requirementType === "points") {
        isUnlocked = points >= achievement.requirementValue;
      } else if (achievement.requirementType === "streak") {
        isUnlocked = habits.some(h => h.streak >= achievement.requirementValue);
      } else if (achievement.requirementType === "completions") {
        isUnlocked = habits.some(h => h.completedDates.length >= achievement.requirementValue);
      }
      return { ...achievement, unlocked: isUnlocked };
    });
  }, [points, habits]);

  const toggleHabit = (id: string) => {
    const today = new Date().toISOString().split('T')[0];
    setHabits(prev => prev.map(habit => {
      if (habit.id === id) {
        const isCompleted = habit.completedDates.includes(today);
        if (isCompleted) {
          setPoints(p => Math.max(0, p - 10));
          return {
            ...habit,
            completedDates: habit.completedDates.filter(d => d !== today),
            streak: Math.max(0, habit.streak - 1),
            dailyProgress: { ...(habit.dailyProgress || {}), [today]: 0 }
          };
        } else {
          setPoints(p => p + 10);
          return {
            ...habit,
            completedDates: [...habit.completedDates, today],
            streak: habit.streak + 1,
            dailyProgress: { ...(habit.dailyProgress || {}), [today]: habit.targetValue || 1 }
          };
        }
      }
      return habit;
    }));
  };

  const updateHabitProgress = (id: string, amount: number) => {
    const today = new Date().toISOString().split('T')[0];
    setHabits(prev => prev.map(habit => {
      if (habit.id === id && habit.goalType === "numeric") {
        const currentProgress = (habit.dailyProgress || {})[today] || 0;
        const newProgress = Math.max(0, currentProgress + amount);
        const wasCompleted = currentProgress >= (habit.targetValue || 1);
        const isCompleted = newProgress >= (habit.targetValue || 1);

        let newCompletedDates = habit.completedDates;
        let newStreak = habit.streak;

        if (!wasCompleted && isCompleted) {
          newCompletedDates = [...habit.completedDates, today];
          newStreak = habit.streak + 1;
          setPoints(p => p + 10);
        } else if (wasCompleted && !isCompleted) {
          newCompletedDates = habit.completedDates.filter(d => d !== today);
          newStreak = Math.max(0, habit.streak - 1);
          setPoints(p => Math.max(0, p - 10));
        }

        return {
          ...habit,
          dailyProgress: { ...(habit.dailyProgress || {}), [today]: newProgress },
          completedDates: newCompletedDates,
          streak: newStreak
        };
      }
      return habit;
    }));
  };

  useEffect(() => {
    notificationService.init(
      (id) => {
        const habit = habitsRef.current.find(h => h.id === id);
        const today = new Date().toISOString().split('T')[0];
        if (habit && !habit.completedDates.includes(today)) {
          toggleHabit(id);
        }
      },
      (id) => {
        const habit = habitsRef.current.find(h => h.id === id);
        if (habit) {
          notificationService.snoozeHabit(habit, t, 15);
        }
      }
    );
  }, [t]);

  useEffect(() => {
    habits.forEach(habit => {
      if (habit.remindersEnabled) {
        notificationService.scheduleNotification(habit, t);
      }
    });
  }, [habits, t]);

  const addHabit = (habit: Omit<Habit, "id" | "streak" | "completedDates" | "createdAt">) => {
    const newHabit: Habit = {
      ...habit,
      id: crypto.randomUUID(),
      streak: 0,
      completedDates: [],
      createdAt: new Date().toISOString(),
    };
    setHabits(prev => [...prev, newHabit]);
    setActiveTab("habits");
  };

  const updateHabit = (id: string, habitData: Partial<Habit>) => {
    setHabits(prev => prev.map(habit => habit.id === id ? { ...habit, ...habitData } : habit));
    setIsEditing(false);
    setActiveTab("details");
  };

  const deleteHabit = (id: string) => {
    setHabits(prev => prev.filter(habit => habit.id !== id));
    setActiveTab("habits");
  };

  const addCategory = (category: Omit<Category, "id">) => {
    const newCategory: Category = {
      ...category,
      id: crypto.randomUUID(),
    };
    setCategories(prev => [...prev, newCategory]);
  };

  const updateCategory = (category: Category) => {
    setCategories(prev => prev.map(cat => cat.id === category.id ? category : cat));
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => prev.filter(cat => cat.id !== id));
    // Optionally reassign habits or delete them. For now, let's just keep them with a broken reference or handle it in UI.
  };

  const resetData = () => {
    if (window.confirm(t.confirm_reset || "Tüm verileri silmek istediğine emin misin?")) {
      setHabits([]);
      setPoints(0);
      setCategories(DEFAULT_CATEGORIES);
      localStorage.removeItem("mindful_flow_v2_habits");
      localStorage.removeItem("mindful_flow_v2_points");
      localStorage.removeItem("mindful_flow_v2_categories");
      window.location.reload();
    }
  };

  const renderView = () => {
    switch (activeTab) {
      case "home": 
        return <HomeView 
          habits={habits} 
          categories={categories}
          toggleHabit={toggleHabit} 
          achievements={unlockedAchievements} 
          points={points}
          level={level}
          t={t} 
          lang={lang}
          onSeeAllHabits={() => setActiveTab("habits")}
          onGoToSettings={() => setActiveTab("profile")}
          onSelectHabit={(id) => {
            setSelectedHabitId(id);
            setActiveTab("details");
          }}
          updateHabitProgress={updateHabitProgress}
        />;
      case "habits": 
        return <HabitsView 
          habits={habits} 
          categories={categories}
          toggleHabit={toggleHabit} 
          onAdd={() => {
            setIsEditing(false);
            setActiveTab("add");
          }} 
          onSelectHabit={(id) => {
            setSelectedHabitId(id);
            setActiveTab("details");
          }}
          updateHabitProgress={updateHabitProgress}
          t={t}
        />;
      case "stats": 
        return <StatsView 
          habits={habits} 
          categories={categories}
          achievements={unlockedAchievements} 
          points={points}
          level={level}
          levelProgress={levelProgress}
          pointsToNextLevel={pointsToNextLevel}
          t={t}
          onSeeAllAchievements={() => setActiveTab("profile")}
        />;
      case "profile": 
        return <ProfileView 
          habits={habits} 
          points={points}
          level={level}
          achievements={unlockedAchievements}
          t={t} 
          lang={lang} 
          setLang={setLang} 
          onManageCategories={() => setActiveTab("categories")}
          onResetData={resetData}
        />;
      case "add": 
        return <AddHabitView 
          categories={categories}
          onAdd={addHabit} 
          onUpdate={updateHabit}
          onBack={() => {
            if (isEditing) setActiveTab("details");
            else setActiveTab("habits");
          }} 
          initialHabit={isEditing ? habits.find(h => h.id === selectedHabitId) : undefined}
          t={t}
        />;
      case "details":
        const habit = habits.find(h => h.id === selectedHabitId);
        if (!habit) {
          setActiveTab("habits");
          return null;
        }
        return <HabitDetailsView 
          habit={habit}
          category={categories.find(c => c.id === habit.categoryId)}
          onBack={() => setActiveTab("habits")}
          onEdit={() => {
            setIsEditing(true);
            setActiveTab("add");
          }}
          onDelete={() => deleteHabit(habit.id)}
          onViewHistory={() => setActiveTab("history")}
          t={t}
        />;
      case "history":
        const historyHabit = habits.find(h => h.id === selectedHabitId);
        if (!historyHabit) {
          setActiveTab("habits");
          return null;
        }
        return <HabitHistoryView 
          habit={historyHabit}
          category={categories.find(c => c.id === historyHabit.categoryId)}
          onBack={() => setActiveTab("details")}
          t={t}
        />;
      case "categories":
        return <CategoriesView 
          categories={categories}
          onAdd={addCategory}
          onUpdate={updateCategory}
          onDelete={deleteCategory}
          onBack={() => setActiveTab("profile")}
          t={t}
        />;
      default: 
        return <HomeView 
          habits={habits} 
          categories={categories}
          toggleHabit={toggleHabit} 
          achievements={unlockedAchievements} 
          points={points}
          level={level}
          t={t}
          lang={lang}
          onSeeAllHabits={() => setActiveTab("habits")}
          onGoToSettings={() => setActiveTab("profile")}
          onSelectHabit={(id) => {
            setSelectedHabitId(id);
            setActiveTab("details");
          }}
          updateHabitProgress={updateHabitProgress}
        />;
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f7ff] text-[#2d2d5f] font-sans pb-24">
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {renderView()}
        </motion.div>
      </AnimatePresence>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-3 flex justify-between items-center z-50">
        <NavButton active={activeTab === "home"} onClick={() => setActiveTab("home")} icon={<HomeIcon size={24} />} label={t.home} />
        <NavButton active={activeTab === "habits"} onClick={() => setActiveTab("habits")} icon={<LayoutList size={24} />} label={t.habits} />
        <div className="relative -top-8">
          <button 
            onClick={() => setActiveTab("add")}
            className="w-14 h-14 bg-[#6366f1] text-white rounded-full shadow-lg shadow-indigo-200 flex items-center justify-center hover:bg-indigo-600 transition-colors"
          >
            <Plus size={32} />
          </button>
        </div>
        <NavButton active={activeTab === "stats"} onClick={() => setActiveTab("stats")} icon={<BarChart3 size={24} />} label={t.stats} />
        <NavButton active={activeTab === "profile"} onClick={() => setActiveTab("profile")} icon={<User size={24} />} label={t.profile} />
      </nav>
    </div>
  );
}

function NavButton({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: ReactNode, label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-1 transition-all flex-1",
        active ? "text-[#6366f1]" : "text-gray-400"
      )}
    >
      <div className={cn(
        "p-2 rounded-2xl transition-colors",
        active && "bg-indigo-50"
      )}>
        {icon}
      </div>
      <span className="text-[10px] font-bold tracking-wider">{label}</span>
    </button>
  );
}
