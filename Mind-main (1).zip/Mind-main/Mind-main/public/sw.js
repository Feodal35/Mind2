self.addEventListener('notificationclick', (event) => {
  const habitId = event.notification.data.habitId;
  const action = event.action;

  event.notification.close();

  if (action === 'complete') {
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
        if (clients.length > 0) {
          clients[0].postMessage({
            type: 'COMPLETE_HABIT',
            habitId: habitId
          });
          return clients[0].focus();
        } else {
          return self.clients.openWindow('/');
        }
      })
    );
  } else if (action === 'snooze') {
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
        if (clients.length > 0) {
          clients[0].postMessage({
            type: 'SNOOZE_HABIT',
            habitId: habitId
          });
          return clients[0].focus();
        } else {
          return self.clients.openWindow('/');
        }
      })
    );
  } else {
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clients) => {
        if (clients.length > 0) {
          return clients[0].focus();
        } else {
          return self.clients.openWindow('/');
        }
      })
    );
  }
});
